angular.module('app.routes', ['jett.ionic.filter.bar'])

.config(function($stateProvider, $urlRouterProvider, $ionicFilterBarConfigProvider) {

    // Ionic uses AngularUI Router which uses the concept of states
    // Learn more here: https://github.com/angular-ui/ui-router
    // Set up the various states which the app can be in.
    // Each state's controller can be found in controllers.js
    $stateProvider
    .state('intro', {
        url: '/Intro',
        templateUrl: 'templates/intro/html/intro.html',
        controller: 'introCtrl'
    })
        .state('approvals', {
            url: '/admin/approvals',
            templateUrl: 'templates/admin/html/approvals.html',
            controller: 'approvalsCtrl'
        })
        .state('manageuser', {
            url: '/admin/manageuser',
            templateUrl: 'templates/admin/html/manageuser.html',
            controller: 'manageuserCtrl'
        })
        .state('managecharity', {
            url: '/admin/managecharity',
            templateUrl: 'templates/admin/html/managecharity.html',
            controller: 'managecharityCtrl'
        })
        .state('manageshelter', {
            url: '/admin/manageshelter',
            templateUrl: 'templates/admin/html/manageshelter.html',
            controller: 'manageshelterCtrl'
        })
        .state('adminshelter', {
            url: '/admin/adminshelter',
            templateUrl: 'templates/admin/html/adminshelter.html',
            controller: 'adminshelterCtrl'
        })
        .state('charity', {
            url: '/charity/:service',
            templateUrl: 'templates/charity/html/charity.html',
            controller: 'charityCtrl'
        })

        .state('detail', {
            url: '/detail/:id',
            templateUrl: 'templates/charity/html/detail.html',
            controller: 'detailCtrl'
        })


    .state('login', {
            url: '/Login',
            templateUrl: 'templates/profile/html/login.html',
            controller: 'loginCtrl'
        })
        .state('changepassword', {
            url: '/ChangePass',
            templateUrl: 'templates/profile/html/changepassword.html',
            controller: 'changePassCtrl'
        })
        .state('forgot', {
            url: '/forgot-password',
            templateUrl: 'templates/profile/html/forgot.html',
            controller: 'forgotCtrl'
        })
        .state('signup', {
            url: '/Signup',
            templateUrl: 'templates/profile/html/signup.html',
            controller: 'signupCtrl'
        })

    .state('about', {
            url: '/About',
            templateUrl: 'templates/about.html',
            controller: 'aboutCtrl'
        })
        .state('terms', {
            url: '/Terms',
            templateUrl: 'templates/terms.html',
            controller: 'termsCtrl'
        })
        .state('favorite', {
            url: '/Favorite',
            templateUrl: 'templates/charity/html/favorite.html',
            controller: 'favoriteCtrl'
        })
        .state('feedback', {
            url: '/Feedback',
            templateUrl: 'templates/feedback/html/feedback.html',
            controller: 'feedbackCtrl'
        })
        .state('flagfeedback', {
            url: '/FlagFeedback',
            templateUrl: 'templates/feedback/html/flagfeedback.html',
            controller: 'flagfeedbackCtrl'
        })
        .state('maps', {
            url: '/maps/:id',
            templateUrl: 'templates/feedback/html/maps.html',
            controller: 'mapsCtrl'
        })
        .state('archive', {
            url: '/Archive',
            templateUrl: 'templates/feedback/html/archive.html',
            controller: 'archiveCtrl'
        })
        .state('charityfeedback', {
            url: '/CharityFeedback',
            templateUrl: 'templates/feedback/html/charityfeedback.html',
            controller: 'charityfeedbackCtrl'
        })
        .state('charityarchive', {
            url: '/CharityArchive',
            templateUrl: 'templates/feedback/html/charityarchive.html',
            controller: 'charityfeedbackCtrl'
        })
        .state('addfeedback', {
            url: '/addFeedback',
            templateUrl: 'templates/feedback/html/addFeedback.html',
            controller: 'addFeedbackCtrl'
        })
        .state('updateCharity', {
            url: '/updateCharity/:id',
            templateUrl: 'templates/charity/html/updateCharity.html',
            controller: 'updateCharityCtrl'
        })
        .state('addCharity', {
            url: '/AddCharity',
            templateUrl: 'templates/charity/html/addCharity.html',
            controller: 'addCharityCtrl'
        })
        .state('addCrisis', {
            url: '/AddCrisis',
            templateUrl: 'templates/charity/html/addCrisislines.html',
            controller: 'addCrisisCtrl'
        })
        .state('editCrisis', {
            url: '/EditCrisis/:id',
            templateUrl: 'templates/charity/html/addCrisislines.html',
            controller: 'editCrisisCtrl'
        })
        .state('Crisis', {
            url: '/Crisis',
            templateUrl: 'templates/charity/html/crisislines.html',
            controller: 'CrisisCtrl'
        })

    //$urlRouterProvider.otherwise('Intro')
    $urlRouterProvider.otherwise('charity/Food')



});
