var appControllers = angular.module('app.controllers', ['firebase'])

.controller('foodCtrl', function($scope) {

})

.controller('shelterCtrl', function($scope) {

})

.controller('healthCtrl', function($scope) {

})

.controller('educationCtrl', function($scope) {

})

.controller('resourcesCtrl', function($scope) {

})

.controller('loginCtrl', function($scope) {

})

.controller('signupCtrl', function($scope) {

})

.controller('aboutCtrl', function($scope,$firebaseObject) {
  var aboutRef = new Firebase(refurl + "staticpages/about");
  /*aboutRef.set({
      content: 'noi dung dang cap nhat'
  });*/
  $scope.obj = $firebaseObject(aboutRef);
  $scope.openlink = function(url) {

      window.open(url, '_system');
  }
})

.controller('termsCtrl', function($scope,$firebaseObject) {
  var termsRef = new Firebase(refurl + "staticpages/terms");
    $scope.obj = $firebaseObject(termsRef);
  /*termsRef.set({
      content: 'noi dung dang cap nhat'
  });*/
})
.controller('soupKitchenNameCtrl', function($scope) {

})

.controller('page12Ctrl', function($scope) {

})

.controller('addCharityCtrl', function($scope) {

})

.controller('adminCtrl', function($scope) {

})

.controller('admin2Ctrl', function($scope) {

})

.controller('charityUserCtrl', function($scope) {

})
