var refurl = "https://yourproject.firebaseio.com/";
angular.module('app', ['ionic', 'ionic.service.core',
        'ionic.service.analytics', 'ionic.service.push', 'app.controllers', 'app.routes',
        'app.services', 'app.directives', 'ngMap', 'ngCordova', 'LocalStorageModule','yaru22.angular-timeago'
    ])
    .run(function($state, $http, $ionicPlatform, $ionicAnalytics,
        $rootScope, $location, $timeout, $ionicSideMenuDelegate,
        $ionicLoading, $firebaseArray, NgMap, $http, $ionicTabsDelegate, localStorageService ) {
        $ionicAnalytics.register();
        $ionicPlatform.ready(function() {
            // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
            // for form inputs)
            if (window.cordova && window.cordova.plugins && window.cordova.plugins.Keyboard) {
                cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
                cordova.plugins.Keyboard.disableScroll(true);
            }
            //ionic.Platform.isFullScreen = true;
            if (window.StatusBar) {
                // org.apache.cordova.statusbar required
                StatusBar.styleDefault();
            }
            /*var push = new Ionic.Push({
                "debug": true
            });

            push.register(function(token) {
                console.log("Device token:", token.token);
                $rootScope.devicetoken = token.token;
                push.saveToken(token); // persist the token in the Ionic Platform
            });*/
            $rootScope.beforestate = "Services";
            $rootScope.shownote=false;
            $rootScope.topkudos = true;
            $rootScope.charitysort = "-kudos";
            $rootScope.currentlocation = "";
            var tmplocation = localStorageService.get('currentlocation');
            if(tmplocation!=null)
            {
              debugger;
              $rootScope.currentlocation=tmplocation;
            }
            $rootScope.openModalCity = function() {
                $rootScope.modalcity.show();
            };
            try {
                cordova.plugins.diagnostic.isLocationEnabled(function(enabled) {
                    console.log("Location is " + (enabled ? "enabled" : "disabled"));
                    $rootScope.allowlocation = enabled;
                    debugger;
                    if (enabled) {
                        console.log("location enabled");
                        if($rootScope.currentlocation=="")
                        {
                          $rootScope.currentlocation="Current Location";
                        }
                    } else {
                        $rootScope.allowlocation = false;
                        cordova.plugins.diagnostic.switchToLocationSettings();
                    }

                }, function(error) {
                    console.error("The following error occurred: " + error);
                });

            } catch (e) {

            }
            if (navigator.geolocation) navigator.geolocation.getCurrentPosition(onPositionUpdate, onError);

            function onPositionUpdate(position) {
                console.log(position);
                $rootScope.lat = position.coords.latitude;
                $rootScope.lng = position.coords.longitude;
                console.log($rootScope.lat + "," + $rootScope.lng);
                $rootScope.topkudos = false;
                $rootScope.charitysort = "distancenumber";
                $rootScope.$broadcast('eventreload', {
                    gender: $rootScope.Gender
                });
                $rootScope.allowlocation = true;
                if($rootScope.currentlocation=="")
                {
                  $rootScope.currentlocation="Current Location";
                }
            }

            function onError(err) {
                console.log(err);
                $rootScope.allowlocation = false;
                $state.go($state.current, {}, {reload: true});
            }

            logout = function() {
                var ref = new Firebase(refurl);
                firebase.auth().signOut().then(function() {
                  // Sign-out successful.
                }).catch(function(error) {
                  // An error happened.
                });
                $rootScope.currentUser = null;
                $rootScope.IsLogin = false;
                $rootScope.IsAdmin = false;
                $rootScope.currentEmail = null;
                localStorageService.remove('email', 'pass');

                /*var push = new Ionic.Push({
                    "debug": true
                });

                push.register(function(token) {
                    console.log("Device token login:", token.token);
                    $rootScope.devicetoken = token.token;
                    push.saveToken(token); // persist the token in the Ionic Platform
                });*/

                $state.go('charity', {
                    'service': 'Food'
                },{cache: false});
            }
            showloading = function() {
                $ionicLoading.show({
                    template: 'Loading...'
                }).then(function() {
                    console.log("The loading indicator is now displayed");
                });
            };
            hideloading = function() {
                $ionicLoading.hide().then(function() {
                    console.log("The loading indicator is now hidden");
                });
            };

            $rootScope.back = function() {
                window.history.back();
            };
            setGender = function(gender) {
                $rootScope.Gender = gender;
                $ionicSideMenuDelegate.toggleLeft();
                $rootScope.$broadcast('eventreload', {
                    gender: gender
                });
            }
            $rootScope.pageindex = 1;
            $rootScope.currentTab = 'Food';
            $rootScope.IsLogin = false;
            $rootScope.IsAdmin = false;
            $rootScope.Gender = "All";
            $rootScope.isshowmenu = true;
            $rootScope.isshowtab = true;
            $rootScope.open = false;
            $rootScope.mapview = false;

            $rootScope.favorite = false;
            $rootScope.keyword = '';
            var refcharity = new Firebase(refurl + "/charity");
            var query = refcharity.orderByChild("approved").equalTo(0);
            $rootScope.manageapprovals = $firebaseArray(query);

            var refuser = new Firebase(refurl + "/users");
            query = refuser.orderByChild("isadmin").equalTo(1);
            $rootScope.manageusers = $firebaseArray(query);
            var reffeedback = new Firebase(refurl + "/feedback");
            query = reffeedback.orderByChild("type").equalTo(1);
            $rootScope.manageFeedback = $firebaseArray(query);
            query = reffeedback.orderByChild("type").equalTo(3);
            $rootScope.manageFeedback2 = $firebaseArray(query);
            $rootScope.userFeedback = 0;

            $rootScope.updateshelter = 0;
            var refshelter = new Firebase(refurl);
            refshelter.child('charity')
                .once('value', function(shelterSnap) {
                    shelterSnap.forEach(function(childSnapshot) {
                        if (childSnapshot.val().service.indexOf('Shelter')!=-1 && childSnapshot.val().avaibed != undefined) {
                            $rootScope.updateshelter = $rootScope.updateshelter + 1;
                        }
                    });
                });

            var refmanageservice = new Firebase(refurl + "/charity");
            $rootScope.manageservice = $firebaseArray(refmanageservice);
            $rootScope.$watch(function() {
                return $ionicSideMenuDelegate.isOpenLeft();
            }, function(isOpen) {
                if (isOpen) {
                    $rootScope.isshowtab = false;
                } else {
                    if ($state.current.name == 'charity') {
                        $rootScope.isshowtab = true;
                    }
                }
            });
            /*var skipintro = localStorageService.get('skipintro');
            if(skipintro && skipintro!="")
            {
              $state.go('charity', {
                  'service': 'Food'
              },{cache: false});
            }*/
            var email = localStorageService.get('email');
            var pass = localStorageService.get('pass');
            if (email && pass && email != "" && pass != "") {
                var ref = new Firebase(refurl);
                firebase.auth().signInWithEmailAndPassword(email,pass).then(function(authData) {
                    hideloading();
                        $rootScope.currentEmail = email;
                        $rootScope.currentUser = authData;
                        $rootScope.IsLogin = true;

                        /*var refuser = new Firebase(refurl + "/users/" + authData.uid);
                        if ($rootScope.devicetoken != undefined) {
                            refuser.update({
                                devicetoken: $rootScope.devicetoken
                            }, function(error) {
                                console.log("Error:", error);
                            });
                        }*/
                        refuser.once('value', function(userSnap) {
                            if (userSnap.val().isadmin == 1) {
                                $rootScope.IsAdmin = true;
                            }
                        });
                        if($rootScope.IsLogin && !$rootScope.IsAdmin)
                        {

                          var refuserfeedback = new Firebase(refurl + "/feedback");
                          refuserfeedback.orderByChild("userid")
                              .equalTo($rootScope.currentUser.uid)
                              .once('value', function(shelterSnap) {
                                  shelterSnap.forEach(function(childSnapshot) {
                                      if (childSnapshot.val().type == 3) {
                                          $rootScope.userFeedback = $rootScope.userFeedback + 1;
                                      }
                                  });
                              });
                        }
                      }).catch(function(error){

                      });
            }
            $rootScope.myGoBack = function() {
              $state.go('charity', {
                  'service': $rootScope.currentTab
              },{cache: false});

             };
            $rootScope.$on('g-places-autocomplete:select', function(event, place) {
                console.log('new location: ' + JSON.stringify(place));
                $rootScope.data = {
                    lat: place.geometry.location.lat(),
                    lng: place.geometry.location.lng()
                };
                //$scope.map.setCenter(place.geometry.location);
                console.log($rootScope.data);
                $rootScope.$broadcast('eventreload', {
                    gender: $rootScope.Gender
                });
            });
            $rootScope.toggleChange = function() {
                if ($rootScope.open == false) {
                    $rootScope.open = true;
                } else {
                    $rootScope.open = false;
                }
                $ionicSideMenuDelegate.toggleLeft();
                $rootScope.$broadcast('eventreload', {
                    gender: $rootScope.Gender
                });
            };

            $rootScope.kudosChange = function()
            {
              if ($rootScope.topkudos == false) {
                  $rootScope.topkudos = true;
                  $rootScope.charitysort = "-kudos";
              } else {
                  $rootScope.topkudos = false;
                  $rootScope.charitysort = "distancenumber";
              }
              $ionicSideMenuDelegate.toggleLeft();
              $rootScope.$broadcast('eventreload', {
                  gender: $rootScope.Gender
              });
            }
            $rootScope.favoriteChange = function()
            {
              if ($rootScope.favorite == false) {
                  $rootScope.favorite = true;
              } else {
                  $rootScope.favorite = false;
              }
              $ionicSideMenuDelegate.toggleLeft();
              $rootScope.$broadcast('eventreload', {
                  gender: $rootScope.Gender
              });
            }
            $rootScope.changesearch = function(keyword)
            {
              $rootScope.keyword=keyword;
              $rootScope.$broadcast('eventreload', {
                  gender: $rootScope.Gender
              });
            }
            $rootScope.mapviewChange = function() {
                if ($rootScope.mapview == false) {
                    $rootScope.mapview = true;
                    $rootScope.isshowtab = false;
                } else {

                    $rootScope.mapview = false;
                    $rootScope.isshowtab = true;
                }
                $state.go('charity', {
                    'service': $rootScope.currentTab,
                },{cache: false});
                var idx = 0;
                if ($rootScope.currentTab == 'Shelter') {
                    idx = 1;
                } else if ($rootScope.currentTab == 'Health') {
                    idx = 2;
                } else if ($rootScope.currentTab == 'Resources') {
                    idx = 3;
                } else if ($rootScope.currentTab == 'Work') {
                    idx = 4;
                }
                $ionicTabsDelegate.select(idx);
                $ionicSideMenuDelegate.toggleLeft();
                $rootScope.$broadcast('eventreload', {
                    gender: $rootScope.Gender
                });

            };

            $rootScope.sendnotificationapproval = function(title, msg) {
                // Define relevant info
                var jwt = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiJjMWI5NDIyYy0wYWJlLTQyOTQtOTdlMi02MTQxZTk5NGJkODYifQ.4DtqbkaO0-bvzYVo-JZ8HdwfvdfF3Bq7AyT86zVDLEM';
                //var tokens = ['your', 'device', 'DEV-167c9d0b-ea6f-413e-bc93-1ead7808fc1d'];
                var tokens = [];
                var ref = new Firebase(refurl);
                ref.child('users')
                    .orderByChild('isadmin')
                    .equalTo(1)
                    .once('value', function(userSnap) {
                        userSnap.forEach(function(childSnapshot) {
                            var key = childSnapshot.key();
                            var obj = childSnapshot.val();
                            if (obj.devicetoken != undefined && obj.devicetoken != "") {
                                tokens.push(obj.devicetoken);
                            }
                        });
                    });


                var profile = 'tester';
                var message = {
                        "tokens": tokens,
                        "profile": profile,
                        "notification": {
                            "title": "Hi",
                            "message": title + " " + msg,
                            "android": {
                                "title": "Hey",
                                "message": title + " " + msg
                            },
                            "ios": {
                                "title": "Howdy",
                                "message": title + " " + msg
                            }
                        }
                    }
                    // Build the request object
                var req = {
                    method: 'POST',
                    url: 'https://api.ionic.io/push/notifications',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer ' + jwt
                    },
                    data: message
                };

                // Make the API call
                $http(req).success(function(resp) {
                    // Handle success
                    console.log("Ionic Push: Push success", resp);
                }).error(function(error) {
                    // Handle error
                    console.log("Ionic Push: Push error", error);
                });
            }
            $rootScope.sendnotificationreport = function(title, msg, uid) {
                // Define relevant info
                var jwt = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiJjMWI5NDIyYy0wYWJlLTQyOTQtOTdlMi02MTQxZTk5NGJkODYifQ.4DtqbkaO0-bvzYVo-JZ8HdwfvdfF3Bq7AyT86zVDLEM';
                //var tokens = ['your', 'device', 'DEV-167c9d0b-ea6f-413e-bc93-1ead7808fc1d'];
                var tokens = [];
                var refuid = new Firebase(refurl+"/users/"+uid);
                refuid.once('value',function(userSnap)
                {
                  var userData = userSnap.val();
                   if (userData.devicetoken != undefined ) {
                       tokens.push(userData.devicetoken);
                   }
                });

                var profile = 'tester';
                var message = {
                        "tokens": tokens,
                        "profile": profile,
                        "notification": {
                            "title": "Hi",
                            "message": title + " " + msg,
                            "android": {
                                "title": "Hey",
                                "message": title + " " + msg
                            },
                            "ios": {
                                "title": "Howdy",
                                "message": title + " " + msg
                            }
                        }
                    }
                    // Build the request object
                var req = {
                    method: 'POST',
                    url: 'https://api.ionic.io/push/notifications',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer ' + jwt
                    },
                    data: message
                };

                // Make the API call
                $http(req).success(function(resp) {
                    // Handle success
                    console.log("Ionic Push: Push success", resp);
                }).error(function(error) {
                    // Handle error
                    console.log("Ionic Push: Push error", error);
                });
            }

            $rootScope.$on('$stateChangeStart',
                function(event, toState, toParams, fromState, fromParams, options) {

                });
            $rootScope.$on('$stateChangeSuccess',
                function(event, toState, toParams, fromState, fromParams, options) {
                  if(fromState.name=='charity' && toState.name=='charity')
                  {$rootScope.pageindex = 1;$rootScope.scrollHeight = 0;}
                    if (toState.name == 'charity') {
                        $rootScope.currentTab = toParams.service;
                        $rootScope.keyword ='';
                        console.log(toParams.service);
                        $rootScope.isshowtab = true;
                        $rootScope.isshowmenu = true;
                    } else if (toState.name == 'approvals' || toState.name == 'manageuser' || toState.name == 'about') {
                        $rootScope.isshowtab = false;
                        $rootScope.isshowmenu = true;
                    } else {
                        $rootScope.isshowtab = false;
                        $rootScope.isshowmenu = false;
                    }

                });
        });

    }).config(function($ionicFilterBarConfigProvider) {
        $ionicFilterBarConfigProvider.placeholder('Search STRAPPD');
    })
