appControllers.controller('addFeedbackCtrl', function($cordovaEmailComposer, $rootScope, $scope, $state, $firebaseArray, $firebaseObject, $ionicPopup, $ionicHistory) {
    var ref = new Firebase(refurl);
    var feedbackref = new Firebase(refurl + "feedback");
    var allfeedback = $firebaseArray(feedbackref);
    $scope.feedBackData = {
        subject: '',
        message: '',
        email:'',
        createdate: new Date().getTime(),
        type:1
    };
    document.addEventListener('deviceready', function() {

    }, false);
    $scope.addFeedback = function() {
      if (!$scope.feedBackData.email) {
          $ionicPopup.alert({
              template: "Please enter email!",
          });
          return false;
      }
        if (!$scope.feedBackData.subject) {
            $ionicPopup.alert({
                template: "Please enter subject!",
            });
            return false;
        }
        if (!$scope.feedBackData.message) {
            $ionicPopup.alert({
                template: "Please enter message!",
            });
            return false;
        }

        allfeedback.$add($scope.feedBackData).then(function(res) {
          $ionicPopup.alert({
              template: "Message Sent Successfully",
          }).then(function(){
            $state.go("charity", {
                'service': 'Food'
            });
          });
            //window.location.href = "mailto:strappdapp@gmail.com?subject="+$scope.feedBackData.subject+"&body="+$scope.feedBackData.message;


        })
    }
});
appControllers.controller('charityfeedbackCtrl', function($rootScope, $scope, $ionicPopup, $filter,$firebaseArray ) {

    var ref = new Firebase(refurl + 'feedback');
    //query = ref.orderByChild("userid").equalTo($rootScope.currentUser.uid);
    //$scope.feedback = $firebaseArray(query);
    $scope.sort = 'createdate';
    $scope.filter = {};
    $scope.filter.feedback = "";
    $scope.feedback = [];
    ref.orderByChild('userid')
        .equalTo($rootScope.currentUser.uid)
        .once('value', function(dataSnap) {
            dataSnap.forEach(function(childSnapshot) {
                var key = childSnapshot.key();
                var childData = childSnapshot.val();
                var obj = {
                  id:key,
                 createdate: childData.createdate,
                 email: childData.email,
                 message: childData.message,
                 name: childData.name,
                 phone: childData.phone,
                 subject: childData.subject,
                 type: childData.type,
                 userid: childData.userid,
                 search:childData.email+","+ childData.name+","+childData.phone+","+childData.subject+","+childData.message
                }
                $scope.feedback.push(obj);
              });
            });
            $scope.Archive = function(feedid,idx) {
              var feedRef = new Firebase(refurl + "feedback/" + feedid);
              feedRef.update({ type: 9 });
              var myEl = angular.element( document.querySelector( '#feedback'+idx ) );
              myEl.remove();
            }
    $scope.deleteFeed = function(feedid,idx) {
        var confirmPopup = $ionicPopup.confirm({
            title: "Delete Feedback",
            template: 'Are you sure you want to remove this feedback?',
            cancelText: 'No',
            okText: 'Yes'
        }).then(function(res) {
          if(res)
          {
            var uidRef = new Firebase(refurl + "feedback/" + feedid);
            var onComplete = function(error) {
                if (error) {
                    alert(error);
                } else {
                  var myEl = angular.element( document.querySelector( '#feedback'+idx ) );
                  myEl.remove();
                    $ionicPopup.alert({
                        title: "",
                        template: "Feedback Deleted Successfully",
                    });
                }
            };
            uidRef.remove(onComplete);
          }
        })

    }
    $scope.sortbyasc=function()
    {
      debugger;
      $scope.sort = 'createdate';
    }
    $scope.sortbydesc=function()
    {
      debugger;
      $scope.sort = '-createdate';
    }
});
appControllers.controller('feedbackCtrl', function($rootScope, $scope, $ionicPopup, $filter,$firebaseArray ) {
  $scope.filter = {};
  $scope.filter.feedback = "";
  $scope.feedback = [];
    var ref = new Firebase(refurl + 'feedback');
    //var query = ref.orderByChild("type").equalTo(1);
    //$scope.feedback = $firebaseArray(query);
    ref.orderByChild('type')
        .equalTo(1)
        .once('value', function(dataSnap) {
            dataSnap.forEach(function(childSnapshot) {
                var key = childSnapshot.key();
                var childData = childSnapshot.val();
                var obj = {
                  id:key,
                 createdate: childData.createdate,
                 email: childData.email,
                 message: childData.message,
                 name: childData.name,
                 phone: childData.phone,
                 subject: childData.subject,
                 type: childData.type,
                 userid: childData.userid,
                 search:childData.email+","+ childData.name+","+childData.phone+","+childData.subject+","+childData.message
                }
                $scope.feedback.push(obj);
              });
            });
            $scope.Archive = function(feedid,idx) {
              var feedRef = new Firebase(refurl + "feedback/" + feedid);
              feedRef.update({ type: 9 });
              var myEl = angular.element( document.querySelector( '#feedback'+idx ) );
              myEl.remove();
            }
    $scope.deleteFeed = function(feedid,idx) {
        var confirmPopup = $ionicPopup.confirm({
            title: "Delete Feedback",
            template: 'Are you sure you want to remove this feedback?',
            cancelText: 'No',
            okText: 'Yes'
        }).then(function(res) {
          if(res)
          {
            var uidRef = new Firebase(refurl + "feedback/" + feedid);
            var onComplete = function(error) {
                if (error) {
                    alert(error);
                } else {
                  var myEl = angular.element( document.querySelector( '#feedback'+idx ) );
                  myEl.remove();
                    $ionicPopup.alert({
                        title: "",
                        template: "Feedback Deleted Successfully",
                    });
                }
            };
            uidRef.remove(onComplete);
          }
        })

    }
    $scope.sortbyasc=function()
    {
      debugger;
      $scope.sort = 'createdate';
    }
    $scope.sortbydesc=function()
    {
      debugger;
      $scope.sort = '-createdate';
    }
});
appControllers.controller('archiveCtrl', function($rootScope, $scope, $ionicPopup, $filter,$firebaseArray ) {
  $scope.filter = {};
  $scope.filter.feedback = "";
  $scope.feedback = [];
    var ref = new Firebase(refurl + 'feedback');
    //var query = ref.orderByChild("type").equalTo(1);
    //$scope.feedback = $firebaseArray(query);
    ref.orderByChild('type')
        .equalTo(9)
        .once('value', function(dataSnap) {
            dataSnap.forEach(function(childSnapshot) {
                var key = childSnapshot.key();
                var childData = childSnapshot.val();
                var obj = {
                  id:key,
                 createdate: childData.createdate,
                 email: childData.email,
                 message: childData.message,
                 name: childData.name,
                 phone: childData.phone,
                 subject: childData.subject,
                 type: childData.type,
                 userid: childData.userid,
                 search:childData.email+","+ childData.name+","+childData.phone+","+childData.subject+","+childData.message
                }
                $scope.feedback.push(obj);
              });
            });
    $scope.deleteFeed = function(feedid,idx) {
        var confirmPopup = $ionicPopup.confirm({
            title: "Delete Feedback",
            template: 'Are you sure you want to remove this feedback?',
            cancelText: 'No',
            okText: 'Yes'
        }).then(function(res) {
          if(res)
          {
            var uidRef = new Firebase(refurl + "feedback/" + feedid);
            var onComplete = function(error) {
                if (error) {
                    alert(error);
                } else {
                  var myEl = angular.element( document.querySelector( '#feedback'+idx ) );
                  myEl.remove();
                    $ionicPopup.alert({
                        title: "",
                        template: "Feedback Deleted Successfully",
                    });
                }
            };
            uidRef.remove(onComplete);
          }
        })

    }
    $scope.sortbyasc=function()
    {
      debugger;
      $scope.sort = 'createdate';
    }
    $scope.sortbydesc=function()
    {
      debugger;
      $scope.sort = '-createdate';
    }
});
appControllers.controller('flagfeedbackCtrl', function($rootScope, $scope, $ionicPopup, $filter,$firebaseArray ) {
  $scope.filter = {};
  $scope.filter.feedback = "";
  $scope.feedback=[];
    var ref = new Firebase(refurl + 'feedback');
    //var query = ref.orderByChild("type").equalTo(3);
    //$scope.feedback = $firebaseArray(query);
    ref.orderByChild('type')
        .equalTo(3)
        .once('value', function(dataSnap) {
            dataSnap.forEach(function(childSnapshot) {
                var key = childSnapshot.key();
                var childData = childSnapshot.val();
                var obj = {
                  id:key,
                 createdate: childData.createdate,
                 email: childData.email,
                 message: childData.message,
                 name: childData.name,
                 phone: childData.phone,
                 subject: childData.subject,
                 type: childData.type,
                 userid: childData.userid,
                 lat:childData.lat,
                 lng:childData.lng,
                 search:childData.email+","+ childData.name+","+childData.phone+","+childData.subject+","+childData.message
                }
                $scope.feedback.push(obj);
              });
            });

            $scope.Archive = function(feedid,idx) {
              var feedRef = new Firebase(refurl + "feedback/" + feedid);
              feedRef.update({ type: 9 });
              var myEl = angular.element( document.querySelector( '#feedback'+idx ) );
              myEl.remove();
            }
    $scope.deleteFeed = function(feedid,idx) {
      debugger;
        var confirmPopup = $ionicPopup.confirm({
            title: "Delete Feedback",
            template: 'Are you sure you want to remove this feedback?',
            cancelText: 'No',
            okText: 'Yes'
        }).then(function(res) {
          if(res)
          {
            var uidRef = new Firebase(refurl + "feedback/" + feedid);
            var onComplete = function(error) {
                if (error) {
                    alert(error);
                } else {
                  var myEl = angular.element( document.querySelector( '#feedback'+idx ) );
                  myEl.remove();
                    $ionicPopup.alert({
                        title: "",
                        template: "Feedback Deleted Successfully",
                    });
                }
            };
            uidRef.remove(onComplete);
          }
        })

    }
    $scope.sortbyasc=function()
    {
      debugger;
      $scope.sort = 'createdate';
    }
    $scope.sortbydesc=function()
    {
      debugger;
      $scope.sort = '-createdate';
    }
});


appControllers.controller('mapsCtrl', function($cordovaEmailComposer, $scope, $state, $http, $ionicPopup, $firebaseObject, $stateParams, NgMap, $filter,$firebaseArray,$ionicHistory,$rootScope,$ionicScrollDelegate,localStorageService ) {
  $scope.id = $stateParams.id;
  NgMap.getMap().then(function(map) {
      //console.log(map.getCenter());
      console.log('markers', map.markers);
      if(map.markers==undefined || map.markers.length==0)
      {
        $scope.showpoint = 1;
      }
      //console.log('shapes', map.shapes);

  });
  var ref = new Firebase(refurl + "/feedback/" + $scope.id);
  $scope.feed = $firebaseObject(ref);

});
