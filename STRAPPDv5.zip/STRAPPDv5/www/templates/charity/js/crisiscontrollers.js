appControllers.controller('CrisisCtrl', function($rootScope,$state, $scope, $ionicPopup, $filter,$firebaseArray,$ionicFilterBar ) {
  $scope.filter = {};
  $scope.filter.crisis = "";
  $scope.crisis=[];
  $rootScope.shownote=false;
  showloading();
    var ref = new Firebase(refurl + 'crisisline');
    ref.once('value', function(dataSnap) {
    if($rootScope.lat==undefined && $rootScope.lng==undefined && $rootScope.currentlocation!="")
    {
      getLatitudeLongitude(callbackLatLng, $rootScope.currentlocation);
      function callbackLatLng(result) {
        $rootScope.lat = result.geometry.location.lat()
        $rootScope.lng = result.geometry.location.lng()
      }
    }
            dataSnap.forEach(function(childSnapshot) {
                var key = childSnapshot.key();
                var childData = childSnapshot.val();
                var obj = {
                 id:key,
                 createdate: childData.createdate,
                 area: childData.area,
                 chatweblink: childData.chatweblink,
                 description: childData.description,
                 hour: childData.hour,
                 name: childData.name,
                 phone: childData.phone,
                 text: childData.text,
                 website: childData.website,
                 lat:0,
                 lng:0,
                 distance:999999999,
                 orderby:$filter('lowercase')(childData.area)=='usa'?1:$filter('lowercase')(childData.area)=='anywhere'?0:2,
                 userid: childData.userid,
                 search:childData.area+","+ childData.chatweblink+","+childData.description+","+childData.hour+","+childData.name+","+childData.phone+","+childData.text+","+childData.website
                }
                if(obj.area!="Anywhere" && 1==2)
                {
                getLatitudeLongitude(callbackLatLng, obj.area);

                function callbackLatLng(result) {
                  obj.lat = result.geometry.location.lat()
                  obj.lng = result.geometry.location.lng()
                  var distance = getDistanceFromLatLonInKm($rootScope.lat,$rootScope.lng,obj.lat,obj.lng).toFixed(1);
                  obj.distance = parseFloat(distance);
                  //$scope.crisis.push(obj);
                  if($rootScope.currentlocation=="" || $rootScope.currentlocation=="Current Location")
                  {
                    $scope.crisis.push(obj);
                  }
                  else if($filter('lowercase')($rootScope.currentlocation)==$filter('lowercase')(obj.area))
                  {
                    $scope.crisis.push(obj);
                  }
                }
              }else {
                $scope.crisis.push(obj);
              }
              $rootScope.shownote=true;
              });
              hideloading();
            });

            $scope.editCrisis=function(id)
            {
                  $state.go('editCrisis', {
                      'id': id
                  });
            }
            $scope.showFilterBar = function() {
              //$rootScope.isshowtab = false;
                filterBarInstance = $ionicFilterBar.show({
                    items: $scope.crisis,
                    update: function(filteredItems, filterText) {
                        $scope.crisis = filteredItems;
                        if($scope.crisis.length==0){
                        $rootScope.shownote = true;
                      }
                      else
                      {
                        $rootScope.shownote = false;
                      }
                        if (filterText) {
                            console.log(filterText);
                        }
                    },
                    done: function() {
                        var input = document.querySelector("ion-filter-bar input.filter-bar-search");
                        if (input) {
                            angular.element(input).attr("placeholder", "Search Crisis Lines");
                        }
                    },
                    cancel: function(){
                      //$rootScope.isshowtab = true;
                    }
                });
            };
            $scope.openchat = function(item) {
                var url = item.chatweblink;
                if (url.indexOf('http://') == -1 && url.indexOf('https://') == -1) {
                    url = 'http://' + url;
                }
                window.open(url, '_system');
            }
            $scope.openwebsite = function(item) {
                var url = item.website;
                if (url.indexOf('http://') == -1 && url.indexOf('https://') == -1) {
                    url = 'http://' + url;
                }
                window.open(url, '_system');
            }
            $scope.deleteCrisis = function(id,idx) {
                var confirmPopup = $ionicPopup.confirm({
                    title: "Delete Crisis Line",
                    template: 'Are you sure you want to delete this Crisis Line?',
                    cancelText: 'No',
                    okText: 'Yes'
                }).then(function(res) {
                  if(res)
                  {
                    var uidRef = new Firebase(refurl + "crisisline/" + id);
                    var onComplete = function(error) {
                        if (error) {
                            alert(error);
                        } else {
                          var myEl = angular.element( document.querySelector( '#crisis'+idx ) );
                          myEl.remove();
                            $ionicPopup.alert({
                                title: "",
                                template: "Crisis Deleted Successfully",
                            });
                        }
                    };
                    uidRef.remove(onComplete);
                  }
                })

            }
            $scope.doRefresh = function() {
              $scope.crisis=[];
                var ref = new Firebase(refurl + 'crisisline');

                ref.once('value', function(dataSnap) {
                        dataSnap.forEach(function(childSnapshot) {
                            var key = childSnapshot.key();
                            var childData = childSnapshot.val();
                            var obj = {
                             id:key,
                             createdate: childData.createdate,
                             area: childData.area,
                             chatweblink: childData.chatweblink,
                             description: childData.description,
                             hour: childData.hour,
                             name: childData.name,
                             phone: childData.phone,
                             text: childData.text,
                             website: childData.website,
                             lat:0,
                             lng:0,
                             distance:999999999,
                             orderby:$filter('lowercase')(childData.area)=='usa'?1:$filter('lowercase')(childData.area)=='anywhere'?0:2,
                             userid: childData.userid,
                             search:childData.area+","+ childData.chatweblink+","+childData.description+","+childData.hour+","+childData.name+","+childData.phone+","+childData.text+","+childData.website
                            }
                            if(obj.area!="Anywhere" && 1==2)
                            {
                              getLatitudeLongitude(callbackLatLng, obj.area);
                              function callbackLatLng(result) {
                                obj.lat = result.geometry.location.lat()
                                obj.lng = result.geometry.location.lng()
                                var distance = getDistanceFromLatLonInKm($rootScope.lat,$rootScope.lng,obj.lat,obj.lng).toFixed(1);
                                obj.distance = parseFloat(distance);
                                if($rootScope.currentlocation=="" || $rootScope.currentlocation=="Current Location")
                                {
                                  $scope.crisis.push(obj);
                                }
                                else if($filter('lowercase')($rootScope.currentlocation)==$filter('lowercase')(obj.area))
                                {
                                  $scope.crisis.push(obj);
                                }
                              }
                            }else {
                                $scope.crisis.push(obj);
                            }
                          });
                        });
              $scope.$broadcast('scroll.refreshComplete');

            };

                    function getLatitudeLongitude(callback, address) {
                        // Initialize the Geocoder
                        geocoder = new google.maps.Geocoder();
                        if (geocoder) {
                            geocoder.geocode({
                                'address': address
                            }, function(results, status) {
                                if (status == google.maps.GeocoderStatus.OK) {
                                    callback(results[0]);
                                }
                            });
                        }
                    }
                    function getDistanceFromLatLonInKm(lat1, lon1, lat2, lon2) {
                        var R = 6371; // Radius of the earth in km
                        var dLat = deg2rad(lat2 - lat1); // deg2rad below
                        var dLon = deg2rad(lon2 - lon1);
                        var a =
                            Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                            Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
                            Math.sin(dLon / 2) * Math.sin(dLon / 2);
                        var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
                        var d = R * c; // Distance in km
                        return d;
                    }
                    function deg2rad(deg) {
                        return deg * (Math.PI / 180)
                    }
});
appControllers.controller('addCrisisCtrl',
    function($scope, $state, $http, $firebaseArray, $ionicPopup, $ionicFilterBar,$filter,$rootScope) {
      var ref = new Firebase(refurl);
      $scope.title="Add Crisis Lines";
      var crisisref = new Firebase(refurl + "crisisline");
      var allcrisis = $firebaseArray(crisisref);
      $scope.crisis = {
        userid: '',
        createdate: new Date().getTime(),
        text:'',
        chatweblink:'',
        website:''
      };
      var authData = firebase.auth().currentUser;
      if (authData) {
          console.log("Authenticated user with uid:", authData.uid);
      } else {
          $state.go("login");
      }
      $scope.addCrisis = function() {
          if (!$scope.crisis.name) {
              $ionicPopup.alert({
                  template: "Please enter Crisic Line Name!",
              });
              return false;
          }
          if (!$scope.crisis.description) {
              $ionicPopup.alert({
                  template: "Please enter Description!",
              });
              return false;
          }

          if (!$scope.crisis.phone) {
              $ionicPopup.alert({
                  template: "Please enter Phone Number!",
              });
              return false;
          }
          if (!$scope.crisis.area) {
              $ionicPopup.alert({
                  template: "Please enter Area it Serves!",
              });
              return false;
          }
          if (!$scope.crisis.hour) {
              $ionicPopup.alert({
                  template: "Please enter Hours of Operation!",
              });
              return false;
          }
          $scope.crisis.userid = authData.uid;
          showloading();

              allcrisis.$add($scope.crisis)
                  .then(function(res) {
                      hideloading();
                      var id = res.key();
                      var confirmPopup = $ionicPopup.confirm({
                          title: "Crisis Line added  successfully",
                          template: 'Do you want to add more Crisis Line?',
                          cancelText: 'No',
                          okText: 'Yes'
                      }).then(function(res) {
                          if (res) {
                              $scope.crisis = {};
                          } else {
                              $state.go("charity", {
                                  'service': 'Food'
                              });
                          }
                      });
                  });

      }
    });

appControllers.controller('editCrisisCtrl',
        function($scope, $state,$stateParams, $http, $firebaseObject, $ionicPopup, $ionicFilterBar,$filter,$rootScope) {
          $scope.id = $stateParams.id;
          var crisisref = new Firebase(refurl + "crisisline/"+$scope.id);
          $scope.crisis = $firebaseObject(crisisref);
          $scope.title="Update Crisis Lines";
          $scope.updateCrisis = function() {
              if (!$scope.crisis.name) {
                  $ionicPopup.alert({
                      template: "Please enter Crisic Line Name!",
                  });
                  return false;
              }
              if (!$scope.crisis.description) {
                  $ionicPopup.alert({
                      template: "Please enter Description!",
                  });
                  return false;
              }

              if (!$scope.crisis.phone) {
                  $ionicPopup.alert({
                      template: "Please enter Phone Number!",
                  });
                  return false;
              }

              if (!$scope.crisis.area) {
                  $ionicPopup.alert({
                      template: "Please enter Area it Serves!",
                  });
                  return false;
              }
              if (!$scope.crisis.hour) {
                  $ionicPopup.alert({
                      template: "Please enter Hours of Operation!",
                  });
                  return false;
              }
              showloading();
              $scope.crisis.$save().then(function() {
                hideloading();
                  var alertPopup = $ionicPopup.alert({
                      template: "Crisis Updated Successfully",
                  });
                  alertPopup.then(function(res) {
                      window.history.back();
                  });

              }).catch(function(error) {
                  $ionicPopup.alert({
                      template: "Crisis Updated Failed: " + error,
                  });
              });

          }
});
