
appControllers.controller('updateCharityCtrl',
    function($scope, $state, $stateParams, $http, $firebaseArray, $firebaseObject, $ionicPopup,$filter) {
        var ref = new Firebase(refurl);
        $scope.charityid = $stateParams.id;
        var tmpservices = [{name:"Food"}, {name:"Shelter"}, {name:"Health"}, {name:"Resources"},{name: "Work"}];
        $scope.lsttype= ["Weekly","Monthly","Date Range","Open 24/7"];
        $scope.period=["First","Second","Third","Fourth","Fifth","Last"];
        var tmp = [{
            name: "Men"
        }, {
            name: "Women"
        }, {
            name: "Kids"
        }, {
            name: "Seniors"
        }, {
            name: "Families"
        }, {
            name: "Veterans"
        }, {
            name: "LGBT+"
        }];
        $scope.category = [];
        $scope.services = [];
        $scope.lstday = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
        $scope.lstclosetype= ["Weekly","Monthly","Date Range","Permanently Closed"];
        var refcharity = new Firebase(refurl + "/charity/" + $scope.charityid);
        $scope.charity = $firebaseObject(refcharity);
        $scope.charity.schedule = [];
        $scope.charity.closeschedule = [];
        $scope.charity.updateshelter = $filter('date')(new Date(), 'MM/dd/yyyy h:mm a');
        var refc = new Firebase(refurl + "/charity/" + $scope.charityid);
        refc.once('value', function(dataSnap) {
            tmp.forEach(function(item) {
                var obj = {
                    name: item.name,
                    value: item.value,
                    checked: (dataSnap.val().category.indexOf(item.name) != -1)
                }
                $scope.category.push(obj);
            });
            $scope.charity.selectedAll = dataSnap.val().category.indexOf('All') != -1;
            tmpservices.forEach(function(item) {
                var obj = {
                    name: item.name,
                    value: item.value,
                    checked: (dataSnap.val().service.indexOf(item.name) != -1)
                }
                $scope.services.push(obj);
            });
        });
        $scope.getshortday = function(day)
        {
        if(day=='Monday'){
          return 'Mon';
        }else if(day=='Tuesday')
        {
          return 'Tue';
        }
        else if(day=='Wednesday')
        {
          return 'Wed';
        }
        else if(day=='Thursday')
        {
          return 'Thu';
        }
        else if(day=='Friday')
        {
          return 'Fri';
        }
        else if(day=='Saturday')
        {
          return 'Sat';
        }
        else if(day=='Sunday')
        {
          return 'Sun';
        }
        }
        $scope.getshortordinal = function(ordinal)
        {
        if(ordinal=='First'){
        return '1st';
        }else if(ordinal=='Second')
        {
        return '2nd';
        }
        else if(ordinal=='Third')
        {
        return '3rd';
        }
        else if(ordinal=='Fourth')
        {
        return '4th';
        }
        else if(ordinal=='Fifth')
        {
        return '5th';
        }
        else if(ordinal=='Last')
        {
        return 'last';
        }
        }
        $scope.checkAll = function() {
            angular.forEach($scope.category, function(item) {
                item.checked = $scope.charity.selectedAll;
            });
        }
        $scope.checkSelect = function() {
            function filterSelect(obj) {
                return obj.checked;
            }
            categoryItemSelect = $scope.category.filter(filterSelect).map(function(obj) {
                return obj.name
            });
            if (categoryItemSelect.length == 7) {
                $scope.charity.selectedAll = true;
            } else {
                $scope.charity.selectedAll = false;
            }
        }
        $scope.checkService = function(service) {
            function filterSelect(obj) {
                return obj.checked && obj.name==service;
            }
            var serviceItemSelect = $scope.services.filter(filterSelect).map(function(obj) {
                return obj.name
            });
            if (serviceItemSelect.length > 0) {
                return true;
            } else {
                return false;
            }
        }
        $scope.checkServiceExist = function() {
            function filterSelect(obj) {
                return obj.checked;
            }
            var serviceItemSelect = $scope.services.filter(filterSelect).map(function(obj) {
                return obj.name
            });
            if (serviceItemSelect.length > 0) {
                return true;
            } else {
                return false;
            }
        }
        $scope.scheduleitem = {selecttype:'Weekly'}
        $scope.scheduleitem2 = {selecttype:'Monthly'}
        $scope.addSchedule = function() {
          debugger;
          if($scope.charity.schedule==null)
          {
            $scope.charity.schedule=[];
          }
          if($scope.scheduleitem.selecttype=='Monthly')
          {
            if (!$scope.scheduleitem.period) {
                $ionicPopup.alert({
                    template: "Please select period!",
                });
                return false;
            }
          }
            if (!$scope.scheduleitem.day && ($scope.scheduleitem.selecttype=='Weekly'||$scope.scheduleitem.selecttype=='Monthly')) {
                $ionicPopup.alert({
                    template: "Please select a day!",
                });
                return false;
            }
            if($scope.scheduleitem.selecttype=='Date Range')
            {
              var datenow = new Date();
              if (!$scope.scheduleitem.date || $scope.scheduleitem.date.getTime() < new Date(datenow.getFullYear(), datenow.getMonth(), datenow.getDate()).getTime()) {
                  $ionicPopup.alert({
                      template: "Please select a current or future date!",
                  });
                  return false;
              }
              if (!$scope.scheduleitem.todate) {
                  $ionicPopup.alert({
                      template: "Please select End Date!",
                  });
                  return false;
              }
              if ($scope.scheduleitem.date.getTime() > $scope.scheduleitem.todate.getTime()) {
                  $ionicPopup.alert({
                      template: "‘End Date’ should be equal or greater than ‘Start Date’ !",
                  });
                  return false;
              }
            }
            if($scope.scheduleitem.selecttype!='Open 24/7'){
              if (!$scope.scheduleitem.from) {
                  $ionicPopup.alert({
                      template: "Please select start time!",
                  });
                  return false;
              }
              if (!$scope.scheduleitem.to) {
                  $ionicPopup.alert({
                      template: "Please select end time!",
                  });
                  return false;
              }
              if ($scope.scheduleitem.from.getTime() >= $scope.scheduleitem.to.getTime()) {
                  $ionicPopup.alert({
                      template: "‘End Time’ should be greater than ‘Start Time’ !",
                  });
                  return false;
              }
            }

            var obj={};
            if($scope.scheduleitem.selecttype=='Weekly')
            {
              obj = {
                  type:$scope.scheduleitem.selecttype,
                  day: $scope.scheduleitem.day,
                  fromstring:$filter('date')(new Date($scope.scheduleitem.from), 'h:mm a'),
                  tostring:$filter('date')(new Date($scope.scheduleitem.to), 'h:mm a')
              }
            }
            if($scope.scheduleitem.selecttype=='Monthly')
            {
              obj = {
                  type:$scope.scheduleitem.selecttype,
                  day: $scope.scheduleitem.day,
                  period: $scope.scheduleitem.period,
                  fromstring:$filter('date')(new Date($scope.scheduleitem.from), 'h:mm a'),
                  tostring:$filter('date')(new Date($scope.scheduleitem.to), 'h:mm a')
              }
            }
            if($scope.scheduleitem.selecttype=='Date Range')
            {
              obj = {
                  type:$scope.scheduleitem.selecttype,
                  date: $filter('date')(new Date($scope.scheduleitem.date), 'MM/dd/yyyy'),
                  todate: $filter('date')(new Date($scope.scheduleitem.todate), 'MM/dd/yyyy'),
                  fromstring:$filter('date')(new Date($scope.scheduleitem.from), 'h:mm a'),
                  tostring:$filter('date')(new Date($scope.scheduleitem.to), 'h:mm a')
              }
            }
            if($scope.scheduleitem.selecttype=='Open 24/7')
            {
              obj = {
                  type:$scope.scheduleitem.selecttype
              }
            }

            $scope.charity.schedule.push(obj);
            $scope.scheduleitem = {selecttype:obj.type};
        }
        $scope.addCloseSchedule = function() {
          if($scope.charity.closeschedule==null)
          {
            $scope.charity.closeschedule=[];
          }
          if($scope.scheduleitem2.selecttype=='Monthly')
          {
            if (!$scope.scheduleitem2.period) {
                $ionicPopup.alert({
                    template: "Please select period!",
                });
                return false;
            }
          }
          if (!$scope.scheduleitem2.day && ($scope.scheduleitem2.selecttype=='Weekly'||$scope.scheduleitem2.selecttype=='Monthly')) {
              $ionicPopup.alert({
                  template: "Please select a day!",
              });
              return false;
          }
            if($scope.scheduleitem2.selecttype=='Date Range')
            {
              var datenow = new Date();
              if (!$scope.scheduleitem2.date || $scope.scheduleitem2.date.getTime() < new Date(datenow.getFullYear(), datenow.getMonth(), datenow.getDate()).getTime()) {
                  $ionicPopup.alert({
                      template: "Please select a current or future date!",
                  });
                  return false;
              }
              if (!$scope.scheduleitem2.todate) {
                  $ionicPopup.alert({
                      template: "Please select End Date!",
                  });
                  return false;
              }
              if ($scope.scheduleitem2.date.getTime() > $scope.scheduleitem2.todate.getTime()) {
                  $ionicPopup.alert({
                      template: "‘End Date’ should be equal or greater than ‘Start Date’ !",
                  });
                  return false;
              }
            }
            if($scope.scheduleitem2.selecttype!='Open 24/7'){
              /*if (!$scope.scheduleitem2.from) {
                  $ionicPopup.alert({
                      template: "Please select start time!",
                  });
                  return false;
              }
              if (!$scope.scheduleitem2.to) {
                  $ionicPopup.alert({
                      template: "Please select end time!",
                  });
                  return false;
              }*/
              if ($scope.scheduleitem2.from!=undefined && $scope.scheduleitem2.to!=undefined && $scope.scheduleitem2.from.getTime() >= $scope.scheduleitem2.to.getTime()) {
                  $ionicPopup.alert({
                      template: "‘End Time’ should be greater than ‘Start Time’ !",
                  });
                  return false;
              }
            }
            var obj={};
            if($scope.scheduleitem2.selecttype=='Weekly')
            {
              obj = {
                  type:$scope.scheduleitem2.selecttype,
                  day: $scope.scheduleitem2.day,
                  fromstring:$filter('date')(new Date($scope.scheduleitem2.from), 'h:mm a'),
                  tostring:$filter('date')(new Date($scope.scheduleitem2.to), 'h:mm a')
              }
            }
            if($scope.scheduleitem2.selecttype=='Monthly')
            {
              if($scope.scheduleitem2.from!=undefined && $scope.scheduleitem2.to!=undefined )
              {
                obj = {
                    type:$scope.scheduleitem2.selecttype,
                    day: $scope.scheduleitem2.day,
                    period: $scope.scheduleitem2.period,
                    fromstring:$filter('date')(new Date($scope.scheduleitem2.from), 'h:mm a'),
                    tostring:$filter('date')(new Date($scope.scheduleitem2.to), 'h:mm a')
                }
              }else{
                obj = {
                    type:$scope.scheduleitem2.selecttype,
                    day: $scope.scheduleitem2.day,
                    period: $scope.scheduleitem2.period
                }
              }
            }
            if($scope.scheduleitem2.selecttype=='Permanently Closed')
            {
              obj = {
                  type:$scope.scheduleitem2.selecttype
              }
            }
            if($scope.scheduleitem2.selecttype=='Date Range')
            {
              if($scope.scheduleitem2.from!=undefined && $scope.scheduleitem2.to!=undefined )
              {
                obj = {
                    type:$scope.scheduleitem2.selecttype,
                    date: $filter('date')(new Date($scope.scheduleitem2.date), 'MM/dd/yyyy'),
                    todate: $filter('date')(new Date($scope.scheduleitem2.todate), 'MM/dd/yyyy'),
                    fromstring:$filter('date')(new Date($scope.scheduleitem2.from), 'h:mm a'),
                    tostring:$filter('date')(new Date($scope.scheduleitem2.to), 'h:mm a')
                }
              }else{
                obj = {
                    type:$scope.scheduleitem2.selecttype,
                    date: $filter('date')(new Date($scope.scheduleitem2.date), 'MM/dd/yyyy'),
                    todate: $filter('date')(new Date($scope.scheduleitem2.todate), 'MM/dd/yyyy')
                }
              }
            }
            if($scope.charity.closeschedule==undefined)
            {
              $scope.charity.closeschedule = [];
            }
            $scope.charity.closeschedule.push(obj);
            $scope.scheduleitem2 = {selecttype:obj.type};
        }
        var authData = firebase.auth().currentUser;
        if (authData) {
            console.log("Authenticated user with uid:", authData.uid);
        } else {
            $state.go("login");
        }

        $scope.deleteSchedule = function(index) {
            $scope.charity.schedule.splice(index, 1);
        }
        $scope.deleteCloseSchedule = function(index) {
            $scope.charity.closeschedule.splice(index, 1);
        }
        var authData = firebase.auth().currentUser;
        if (authData) {
            console.log("Authenticated user with uid:", authData.uid);
        } else {
            $state.go("login");
        }
        /*var refuid = new Firebase(refurl+"/users/"+authData.uid);
        var objuser = $firebaseObject(refuid);
        refuid.once('value',function(userSnap)
        {
          $scope.charityname = userSnap.val().name;
        });*/


        $scope.updateCharity = function() {
          debugger;
            if (!$scope.charity.charityname) {
                $ionicPopup.alert({
                    template: "Please enter Service Name!",
                });
                return false;
            }
            if (!$scope.charity.address1) {
                $ionicPopup.alert({
                    template: "Please enter Address!",
                });
                return false;
            }
            if (!$scope.charity.city) {
                $ionicPopup.alert({
                    template: "Please enter City!",
                });
                return false;
            }
            if (!$scope.charity.state) {
                $ionicPopup.alert({
                    template: "Please enter State!",
                });
                return false;
            }
            if (!$scope.charity.zip) {
                $ionicPopup.alert({
                    template: "Please enter Zip Code!",
                });
                return false;
            }

            function filterService(obj) {
                return obj.checked;
            }
            serviceItemSelect = $scope.services.filter(filterService).map(function(obj) {
                return obj.name
            });
            if (serviceItemSelect.length == 0) {
                $ionicPopup.alert({
                    template: "Please select a service!",
                });
                return false;
            }
            $scope.charity.service = serviceItemSelect.join(',');
            if (!$scope.charity.servicetype) {
                $ionicPopup.alert({
                    template: "Enter Service Type!",
                });
                return false;
            }

              if($scope.charity.totalbed && $scope.charity.avaibed && $scope.charity.totalbed<$scope.charity.avaibed)
              {
                $ionicPopup.alert({
                    template: "‘Total Beds’ should be greater than ‘Available Beds’!",
                });
                return false;
              }

            function filterSelect(obj) {
                return obj.checked;
            }
            categoryItemSelect = $scope.category.filter(filterSelect).map(function(obj) {
                return obj.name
            });
            if (categoryItemSelect.length == 0) {
                $ionicPopup.alert({
                    template: "Please select a Category!",
                });
                return false;
            }
            $scope.charity.category = categoryItemSelect.join(',');
            if ($scope.charity.selectedAll) {
                $scope.charity.category = categoryItemSelect.join(',') + ",All";
            }
            if ($scope.charity.schedule!= undefined &&$scope.charity.schedule.length == 0 && !$scope.charity.contact) {
                $ionicPopup.alert({
                    template: "Please add a Schedule!",
                });
                return false;
            }

            if (!$scope.charity.description) {
                $ionicPopup.alert({
                    template: "Please enter Description or Comments!",
                });
                return false;
            }
            if($scope.charity.useremail)
            {
              var refuser = new Firebase(refurl + "/users");
              refuser.orderByChild("email").equalTo(angular.lowercase($scope.charity.useremail)).once("value", function(snapshot) {
                $scope.charity.useremail='';
                snapshot.forEach(function(childSnapshot) {
                  var key = childSnapshot.key();
                  var childData = childSnapshot.val();
                  $scope.charity.userid=childData.userid;
                  $scope.charity.useremail = childData.email;
                })
              });
            }
            //showloading();
            //update charity

            var address = $scope.charity.address1 + ", " + $scope.charity.city + ", " + $scope.charity.state;
            getLatitudeLongitude(callbackLatLng, address);

            function callbackLatLng(result) {
                $scope.charity.lat = result.geometry.location.lat()
                $scope.charity.lng = result.geometry.location.lng()

                $scope.charity.$save().then(function() {
                    var alertPopup = $ionicPopup.alert({
                        template: "Service Updated Successfully",
                    });
                    alertPopup.then(function(res) {
                        window.history.back();
                    });

                }).catch(function(error) {
                    $ionicPopup.alert({
                        template: "Service Updated Failed: " + error,
                    });
                });
            }
        }

        function getLatitudeLongitude(callback, address) {
            // Initialize the Geocoder
            geocoder = new google.maps.Geocoder();
            if (geocoder) {
                geocoder.geocode({
                    'address': address
                }, function(results, status) {
                    if (status == google.maps.GeocoderStatus.OK) {
                        callback(results[0]);
                    }
                });
            }
        }

    });
