
appControllers.controller('addCharityCtrl',
    function($scope, $state, $http, $firebaseArray, $ionicPopup, $ionicFilterBar,$filter,$rootScope) {

        var ref = new Firebase(refurl);
        var charityref = new Firebase(refurl + "charity");
        var allcharity = $firebaseArray(charityref);
        $scope.services = [{name:"Food"}, {name:"Shelter"}, {name:"Health"}, {name:"Resources"},{name: "Work"}];

        $scope.category = [{
            name: "Men"
        }, {
            name: "Women"
        }, {
            name: "Kids"
        }, {
            name: "Seniors"
        }, {
            name: "Families"
        }, {
            name: "Veterans"
        }, {
            name: "LGBT+"
        }];
        $scope.lstday = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
        $scope.lsttype= ["Weekly","Monthly","Date Range","Open 24/7"];
        $scope.lstclosetype= ["Weekly","Monthly","Date Range","Permanently Closed"];
        $scope.period=["First","Second","Third","Fourth","Fifth","Last"];
        $scope.charity = {
            schedule: [],
            closeschedule: [],
            userid: '',
            approved: 0,
            lat: 0,
            lng: 0,
            kudos:0,
            updateshelter:''
        };
        $scope.charity.updateshelter=$filter('date')(new Date(), 'MM/dd/yyyy h:mm a');
        $scope.scheduleitem = {selecttype:'Weekly'};
        $scope.scheduleitem2 = {selecttype:'Monthly'};
        $scope.checkAll = function() {
            angular.forEach($scope.category, function(item) {
                item.checked = $scope.charity.selectedAll;
            });

        };
        $scope.getshortday = function(day)
      {
        if(day=='Monday'){
          return 'Mon';
        }else if(day=='Tuesday')
        {
          return 'Tue';
        }
        else if(day=='Wednesday')
        {
          return 'Wed';
        }
        else if(day=='Thursday')
        {
          return 'Thu';
        }
        else if(day=='Friday')
        {
          return 'Fri';
        }
        else if(day=='Saturday')
        {
          return 'Sat';
        }
        else if(day=='Sunday')
        {
          return 'Sun';
        }
      }
      $scope.getshortordinal = function(ordinal)
    {
      if(ordinal=='First'){
        return '1st';
      }else if(ordinal=='Second')
      {
        return '2nd';
      }
      else if(ordinal=='Third')
      {
        return '3rd';
      }
      else if(ordinal=='Fourth')
      {
        return '4th';
      }
      else if(ordinal=='Fifth')
      {
        return '5th';
      }
      else if(ordinal=='Last')
      {
        return 'last';
      }
    }
        $scope.checkSelect = function() {
            function filterSelect(obj) {
                return obj.checked;
            }
            categoryItemSelect = $scope.category.filter(filterSelect).map(function(obj) {
                return obj.name
            });
            if (categoryItemSelect.length == 7) {
                $scope.charity.selectedAll = true;
            } else {
                $scope.charity.selectedAll = false;
            }
        }
        $scope.checkService = function(service) {
            function filterSelect(obj) {
                return obj.checked && obj.name==service;
            }
            var serviceItemSelect = $scope.services.filter(filterSelect).map(function(obj) {
                return obj.name
            });
            if (serviceItemSelect.length > 0) {
                return true;
            } else {
                return false;
            }
        }
        $scope.checkServiceExist = function() {
            function filterSelect(obj) {
                return obj.checked;
            }
            var serviceItemSelect = $scope.services.filter(filterSelect).map(function(obj) {
                return obj.name
            });
            if (serviceItemSelect.length > 0) {
                return true;
            } else {
                return false;
            }
        }
        $scope.addSchedule = function() {
          if($scope.charity.schedule==null)
          {
            $scope.charity.schedule=[];
          }
          if($scope.scheduleitem.selecttype=='Monthly')
          {
            if (!$scope.scheduleitem.period) {
                $ionicPopup.alert({
                    template: "Please select period!",
                });
                return false;
            }
          }
            if (!$scope.scheduleitem.day && ($scope.scheduleitem.selecttype=='Weekly'||$scope.scheduleitem.selecttype=='Monthly')) {
                $ionicPopup.alert({
                    template: "Please select a day!",
                });
                return false;
            }

            if($scope.scheduleitem.selecttype=='Date Range')
            {
              var datenow = new Date();
              if (!$scope.scheduleitem.date || $scope.scheduleitem.date.getTime() < new Date(datenow.getFullYear(), datenow.getMonth(), datenow.getDate()).getTime()) {
                  $ionicPopup.alert({
                      template: "Please select a current or future date!",
                  });
                  return false;
              }
              if (!$scope.scheduleitem.todate) {
                  $ionicPopup.alert({
                      template: "Please select End Date!",
                  });
                  return false;
              }
              if ($scope.scheduleitem.date.getTime() > $scope.scheduleitem.todate.getTime()) {
                  $ionicPopup.alert({
                      template: "‘End Date’ should be equal or greater than ‘Start Date’ !",
                  });
                  return false;
              }
            }

            if($scope.scheduleitem.selecttype!='Open 24/7'){
              if (!$scope.scheduleitem.from) {
                  $ionicPopup.alert({
                      template: "Please select start time!",
                  });
                  return false;
              }
              if (!$scope.scheduleitem.to) {
                  $ionicPopup.alert({
                      template: "Please select end time!",
                  });
                  return false;
              }
              if ($scope.scheduleitem.from.getTime() >= $scope.scheduleitem.to.getTime()) {
                  $ionicPopup.alert({
                      template: "‘End Time’ should be greater than ‘Start Time’ !",
                  });
                  return false;
              }
            }
            var obj={};
            if($scope.scheduleitem.selecttype=='Weekly')
            {
              obj = {
                  type:$scope.scheduleitem.selecttype,
                  day: $scope.scheduleitem.day,
                  fromstring:$filter('date')(new Date($scope.scheduleitem.from), 'h:mm a'),
                  tostring:$filter('date')(new Date($scope.scheduleitem.to), 'h:mm a')
              }
            }
            if($scope.scheduleitem.selecttype=='Monthly')
            {
              obj = {
                  type:$scope.scheduleitem.selecttype,
                  day: $scope.scheduleitem.day,
                  period: $scope.scheduleitem.period,
                  fromstring:$filter('date')(new Date($scope.scheduleitem.from), 'h:mm a'),
                  tostring:$filter('date')(new Date($scope.scheduleitem.to), 'h:mm a')
              }
            }
            if($scope.scheduleitem.selecttype=='Date Range')
            {
              obj = {
                  type:$scope.scheduleitem.selecttype,
                  date: $filter('date')(new Date($scope.scheduleitem.date), 'MM/dd/yyyy'),
                  todate: $filter('date')(new Date($scope.scheduleitem.todate), 'MM/dd/yyyy'),
                  fromstring:$filter('date')(new Date($scope.scheduleitem.from), 'h:mm a'),
                  tostring:$filter('date')(new Date($scope.scheduleitem.to), 'h:mm a')
              }
            }

            if($scope.scheduleitem.selecttype=='Open 24/7')
            {
              obj = {
                  type:$scope.scheduleitem.selecttype
              }
            }
            $scope.charity.schedule.push(obj);
            $scope.scheduleitem = {selecttype:obj.type};
        }

        $scope.addCloseSchedule = function() {
          if($scope.charity.closeschedule==null)
          {
            $scope.charity.closeschedule=[];
          }
          if($scope.scheduleitem2.selecttype=='Monthly')
          {
            if (!$scope.scheduleitem2.period) {
                $ionicPopup.alert({
                    template: "Please select period!",
                });
                return false;
            }
          }
            if (!$scope.scheduleitem2.day && ($scope.scheduleitem2.selecttype=='Weekly'||$scope.scheduleitem2.selecttype=='Monthly')) {
                $ionicPopup.alert({
                    template: "Please select a day!",
                });
                return false;
            }
            if($scope.scheduleitem2.selecttype=='Date Range')
            {
              var datenow = new Date();
              if (!$scope.scheduleitem2.date || $scope.scheduleitem2.date.getTime() < new Date(datenow.getFullYear(), datenow.getMonth(), datenow.getDate()).getTime()) {
                  $ionicPopup.alert({
                      template: "Please select a current or future date!",
                  });
                  return false;
              }
              if (!$scope.scheduleitem2.todate) {
                  $ionicPopup.alert({
                      template: "Please select End Date!",
                  });
                  return false;
              }
              if ($scope.scheduleitem2.date.getTime() > $scope.scheduleitem2.todate.getTime()) {
                  $ionicPopup.alert({
                      template: "‘End Date’ should be equal or greater than ‘Start Date’ !",
                  });
                  return false;
              }
            }

            if($scope.scheduleitem2.selecttype!='Open 24/7'){
              /*if (!$scope.scheduleitem2.from) {
                  $ionicPopup.alert({
                      template: "Please select start time!",
                  });
                  return false;
              }
              if (!$scope.scheduleitem2.to) {
                  $ionicPopup.alert({
                      template: "Please select end time!",
                  });
                  return false;
              }*/
              if ($scope.scheduleitem2.from!=undefined && $scope.scheduleitem2.to!=undefined && $scope.scheduleitem2.from.getTime() >= $scope.scheduleitem2.to.getTime()) {
                  $ionicPopup.alert({
                      template: "‘End Time’ should be greater than ‘Start Time’ !",
                  });
                  return false;
              }
            }
            var obj={};
            if($scope.scheduleitem2.selecttype=='Weekly')
            {
              obj = {
                  type:$scope.scheduleitem2.selecttype,
                  day: $scope.scheduleitem2.day,
                  fromstring:$filter('date')(new Date($scope.scheduleitem2.from), 'h:mm a'),
                  tostring:$filter('date')(new Date($scope.scheduleitem2.to), 'h:mm a')
              }
            }
            if($scope.scheduleitem2.selecttype=='Monthly')
            {
              if($scope.scheduleitem2.from!=undefined && $scope.scheduleitem2.to!=undefined)
              {
                obj = {
                    type:$scope.scheduleitem2.selecttype,
                    day: $scope.scheduleitem2.day,
                    period: $scope.scheduleitem2.period,
                    fromstring:$filter('date')(new Date($scope.scheduleitem2.from), 'h:mm a'),
                    tostring:$filter('date')(new Date($scope.scheduleitem2.to), 'h:mm a')
                }
              }else{
                obj = {
                    type:$scope.scheduleitem2.selecttype,
                    day: $scope.scheduleitem2.day,
                    period: $scope.scheduleitem2.period
                }
              }
            }
            if($scope.scheduleitem2.selecttype=='Permanently Closed')
            {
              obj = {
                  type:$scope.scheduleitem2.selecttype
              }
            }
            if($scope.scheduleitem2.selecttype=='Date Range')
            {
              if($scope.scheduleitem2.from!=undefined && $scope.scheduleitem2.to!=undefined)
              {
                obj = {
                    type:$scope.scheduleitem2.selecttype,
                    date: $filter('date')(new Date($scope.scheduleitem2.date), 'MM/dd/yyyy'),
                    todate: $filter('date')(new Date($scope.scheduleitem2.todate), 'MM/dd/yyyy'),
                    fromstring:$filter('date')(new Date($scope.scheduleitem2.from), 'h:mm a'),
                    tostring:$filter('date')(new Date($scope.scheduleitem2.to), 'h:mm a')
                }
              }else{
                obj = {
                    type:$scope.scheduleitem2.selecttype,
                    date: $filter('date')(new Date($scope.scheduleitem2.date), 'MM/dd/yyyy'),
                    todate: $filter('date')(new Date($scope.scheduleitem2.todate), 'MM/dd/yyyy')
                }
              }
            }
            $scope.charity.closeschedule.push(obj);
            $scope.scheduleitem2 = {selecttype:obj.type};
        }
        var authData = firebase.auth().currentUser;
        if (authData) {
            console.log("Authenticated user with uid:", authData.uid);
        } else {
            $state.go("login");
        }

        $scope.deleteSchedule = function(index) {
            $scope.charity.schedule.splice(index, 1);
        }
        $scope.deleteCloseSchedule = function(index) {
            $scope.charity.closeschedule.splice(index, 1);
        }
        if(!$rootScope.IsAdmin)
        {
          $scope.charity.showflag=true;
          $scope.charity.showdonate=true;
        }
        $scope.addCharity = function() {
            if (!$scope.charity.charityname) {
                $ionicPopup.alert({
                    template: "Please enter Service Name!",
                });
                return false;
            }
            if (!$scope.charity.address1) {
                $ionicPopup.alert({
                    template: "Please enter Address!",
                });
                return false;
            }
            if (!$scope.charity.city) {
                $ionicPopup.alert({
                    template: "Please enter City!",
                });
                return false;
            }
            if (!$scope.charity.state) {
                $ionicPopup.alert({
                    template: "Please enter State!",
                });
                return false;
            }
            if (!$scope.charity.zip) {
                $ionicPopup.alert({
                    template: "Please enter Zip Code!",
                });
                return false;
            }
            /*if (!$scope.charity.service) {
                $ionicPopup.alert({
                    template: "Please select a Service!",
                });
                return false;
            }*/
            function filterService(obj) {
                return obj.checked;
            }
            serviceItemSelect = $scope.services.filter(filterService).map(function(obj) {
                return obj.name
            });
            if (serviceItemSelect.length == 0) {
                $ionicPopup.alert({
                    template: "Please select a service!",
                });
                return false;
            }
            $scope.charity.service = serviceItemSelect.join(',');

            if (!$scope.charity.servicetype) {
                $ionicPopup.alert({
                    template: "Enter Service Type!",
                });
                return false;
            }

              if($scope.charity.totalbed && $scope.charity.avaibed && $scope.charity.totalbed<$scope.charity.avaibed)
              {
                $ionicPopup.alert({
                    template: "‘Total Beds’ should be greater than ‘Available Beds’!",
                });
                return false;
              }

            function filterSelect(obj) {
                return obj.checked;
            }
            categoryItemSelect = $scope.category.filter(filterSelect).map(function(obj) {
                return obj.name
            });
            if (categoryItemSelect.length == 0) {
                $ionicPopup.alert({
                    template: "Please select a Category!",
                });
                return false;
            }
            $scope.charity.category = categoryItemSelect.join(',');
            if ($scope.charity.selectedAll) {
                $scope.charity.category = categoryItemSelect.join(',') + ",All";
            }
            if ($scope.charity.schedule.length == 0 && !$scope.charity.contact) {
                $ionicPopup.alert({
                    template: "Please add a Schedule!",
                });
                return false;
            }

            if (!$scope.charity.description) {
                $ionicPopup.alert({
                    template: "Please enter Description or Comments!",
                });
                return false;
            }

            showloading();

            var flag = 1;
            if($scope.charity.useremail)
            {
              var refuser = new Firebase(refurl + "/users");
              refuser.orderByChild("email").equalTo(angular.lowercase($scope.charity.useremail)).once("value", function(snapshot) {
                snapshot.forEach(function(childSnapshot) {
                  var key = childSnapshot.key();
                  var childData = childSnapshot.val();
                  $scope.charity.userid=childData.userid;
                  $scope.charity.useremail=childData.email;
                  flag = 0;
                })
              });
            }
            if(flag==1) {
              var refuid = new Firebase(refurl+"/users/"+authData.uid);
              refuid.once('value',function(userSnap)
              {
                var userData = userSnap.val();
                 $scope.charity.useremail = userData.email;
                 $scope.charity.userid = userData.userid;
              });
            }

            var address = $scope.charity.address1 + ", " + $scope.charity.city + ", " + $scope.charity.state;
            getLatitudeLongitude(callbackLatLng, address);

            function callbackLatLng(result) {
                $scope.charity.lat = result.geometry.location.lat()
                $scope.charity.lng = result.geometry.location.lng()

                allcharity.$add($scope.charity)
                    .then(function(res) {
                        hideloading();
                        var id = res.key();
                        $rootScope.sendnotificationapproval($scope.charity.charityname,'Waiting for Approval.');
                        var confirmPopup = $ionicPopup.confirm({
                            title: $scope.charity.service + " Service added  successfully",
                            template: 'Do you want to add more Services?',
                            cancelText: 'No',
                            okText: 'Yes'
                        }).then(function(res) {
                            if (res) {
                                $scope.charity = {
                                    schedule: [],
                                    userid: '',
                                    approved: 0
                                };
                                angular.forEach($scope.category, function(item) {
                                    item.checked = false;
                                });
                            } else {
                                $state.go("charity", {
                                    'service': 'Food'
                                });
                            }
                        });
                    });

            }

        }

        function getLatitudeLongitude(callback, address) {
            // Initialize the Geocoder
            geocoder = new google.maps.Geocoder();
            if (geocoder) {
                geocoder.geocode({
                    'address': address
                }, function(results, status) {
                    if (status == google.maps.GeocoderStatus.OK) {
                        callback(results[0]);
                    }
                });
            }
        }
    });

appControllers.controller('detailCtrl', function($cordovaEmailComposer, $scope, $state, $http, $ionicPopup, $firebaseObject, $stateParams, NgMap, $filter,$firebaseArray,$ionicHistory,$rootScope,$ionicScrollDelegate,localStorageService ) {
  $scope.myGoBack = function() {
    $state.go('charity', {
        'service': $rootScope.currentTab
    },{cache: false});

   };
    $scope.$on('$ionicView.beforeEnter', function() {
      $scope.showpoint = 0;
        NgMap.getMap().then(function(map) {
            //console.log(map.getCenter());
            console.log('markers', map.markers);
            if(map.markers==undefined || map.markers.length==0)
            {
              $scope.showpoint = 1;
            }
            //console.log('shapes', map.shapes);

        });

        if($rootScope.lat)
        {
          $scope.showpoint = 0;
        }
        else {
          $scope.showpoint = 1;
        }

        $scope.favorited = false;
        /*if($rootScope.currentUser)
        {
        var reffavorite = new Firebase(refurl+"/favorite");
        reffavorite.orderByChild("userid").equalTo($rootScope.currentUser.uid).once("value", function(snapshot) {
          snapshot.forEach(function(childSnapshot) {
            var key = childSnapshot.key();
            var childData = childSnapshot.val();
            if($scope.id==childData.charityid)
            {
              $scope.favorited = true;
            }
          })
        });
      }*/
        $scope.data = {};
        $scope.id = $stateParams.id;
        $scope.datenow = new Date().getTime();
        var ref = new Firebase(refurl + "/charity/" + $scope.id);

        var favoritelist = localStorageService.get('favorite');
        if(favoritelist!=null && favoritelist.indexOf($scope.id)!=-1)
        {
          $scope.favorited = true;
        }

        $scope.charity = $firebaseObject(ref);
        $scope.schedule = [];
        $scope.closeschedule = [];
        ref.once('value', function(charitySnap) {
            angular.forEach(charitySnap.val().schedule, function(item) {

                var addToArray = true;
                if (item.type == 'Weekly') {
                    for (var i = 0; i < $scope.schedule.length; i++) {
                        if ($scope.schedule[i].name === item.day) {
                            addToArray = false;
                            //$scope.schedule[i].value = $scope.schedule[i].value + "<br>" + $filter('date')(new Date(item.from), 'h:mm a') + " - " + $filter('date')(new Date(item.to), 'h:mm a');
                            $scope.schedule[i].value = $scope.schedule[i].value + "<br>" +item.fromstring + " - " + item.tostring;
                        }
                    }
                }
                else if(item.type=='Date Range'){
                  var totime = new Date('06/01/2016 '+item.tostring);
                  var dateto = new Date(item.todate).setHours(totime.getHours());
                  dateto = new Date(dateto).setMinutes(totime.getMinutes());

                  if(dateto<$scope.datenow)
                  {
                    addToArray=false;
                  }
                }
                if (addToArray && (item.type=='Weekly' || item.type=='Date Range')) {
                  var datename = item.day;
                  if(item.date!=undefined && item.date==item.todate)
                  {
                    datename =item.date;
                  }
                  else if(item.date!=undefined && item.date!= item.todate)
                  {
                    datename = item.date +" - " + item.todate;
                  }
                    var obj = {
                        name: datename,
                        //value: $filter('date')(new Date(item.from), 'h:mm a') + " - " + $filter('date')(new Date(item.to), 'h:mm a')
                        value: item.fromstring + " - " + item.tostring
                    };
                    $scope.schedule.push(obj);
                }
                else if(item.type=='Open 24/7')
                {
                  $scope.schedule.push({name: 'Open 24/7',value:''});
                }
                else if(item.type=='Monthly')
                {
                  var obj = {
                    name: getshortordinal(item.period) +" " + getshortday(item.day),
                    value: item.fromstring + " - " + item.tostring
                  }
                  $scope.schedule.push(obj);
                }
            });

            //close schedule
            angular.forEach(charitySnap.val().closeschedule, function(item) {
debugger;
                var addToArray = true;
                if (item.type == 'Weekly') {
                    for (var i = 0; i < $scope.closeschedule.length; i++) {
                        if ($scope.closeschedule[i].name === item.day) {
                            addToArray = false;
                            //$scope.schedule[i].value = $scope.schedule[i].value + "<br>" + $filter('date')(new Date(item.from), 'h:mm a') + " - " + $filter('date')(new Date(item.to), 'h:mm a');
                            $scope.closeschedule[i].value = $scope.closeschedule[i].value + "<br>" +item.fromstring + " - " + item.tostring;
                        }
                    }
                }
                if(item.type=='Date Range'){
                  var totime = new Date('06/01/2016 '+item.tostring);
                  var dateto = new Date(item.todate).setHours(totime.getHours());
                  dateto = new Date(dateto).setMinutes(totime.getMinutes());

                  if(dateto<$scope.datenow)
                  {
                    addToArray=false;
                  }
                }
                  if (addToArray && (item.type=='Weekly' || item.type=='Date Range')) {
                  var datename = item.day;
                  if(item.date!=undefined && item.date==item.todate)
                  {
                    datename =item.date;
                  }
                  else if(item.date!=undefined && item.date!= item.todate)
                  {
                    datename = item.date +" - " + item.todate;
                  }
                    var obj={};
                    if(item.fromstring!=null && item.tostring!=null)
                    {
                    obj = {
                        name: datename,
                        //value: $filter('date')(new Date(item.from), 'h:mm a') + " - " + $filter('date')(new Date(item.to), 'h:mm a')
                        value: item.fromstring + " - " + item.tostring
                    };
                  }
                  else{
                    obj = {
                        name: datename,
                        //value: $filter('date')(new Date(item.from), 'h:mm a') + " - " + $filter('date')(new Date(item.to), 'h:mm a')
                        value: ""
                    };
                  }
                    $scope.closeschedule.push(obj);
                }
                else if(item.type=='Monthly')
                {
                  var obj={};
                  if(item.fromstring!=null && item.tostring!=null)
                  {
                  obj = {
                    name: getshortordinal(item.period) +" " + getshortday(item.day),
                    value: item.fromstring + " - " + item.tostring
                  }
                }
                else {
                  obj = {
                    name: getshortordinal(item.period) +" " + getshortday(item.day),
                    value: ""
                  }
                }
                  $scope.closeschedule.push(obj);
                }
            });
        });
        function getshortday(day)
      {
        return day;
        if(day=='Monday'){
          return 'Mon';
        }else if(day=='Tuesday')
        {
          return 'Tue';
        }
        else if(day=='Wednesday')
        {
          return 'Wed';
        }
        else if(day=='Thursday')
        {
          return 'Thu';
        }
        else if(day=='Friday')
        {
          return 'Fri';
        }
        else if(day=='Saturday')
        {
          return 'Sat';
        }
        else if(day=='Sunday')
        {
          return 'Sun';
        }
      }
      function getshortordinal(ordinal)
      {
      if(ordinal=='First'){
        return '1st';
      }else if(ordinal=='Second')
      {
        return '2nd';
      }
      else if(ordinal=='Third')
      {
        return '3rd';
      }
      else if(ordinal=='Fourth')
      {
        return '4th';
      }
      else if(ordinal=='Fifth')
      {
        return '5th';
      }
      else if(ordinal=='Last')
      {
        return 'Last';
      }
      }

        $scope.openwebsite = function(url) {

            if (url.indexOf('http://') == -1 && url.indexOf('https://') == -1) {
                url = 'http://' + url;
            }
            window.open(url, '_system');
        }

        $scope.showMap = function(charity) {
          if($rootScope.lat)
          {
            var link = "http://maps.google.com/maps?saddr=" + $rootScope.lat + "," + $rootScope.lng + " &daddr=" + ($scope.charity.address1 + ',' + $scope.charity.city + ',' + $scope.charity.state)+"&mode=transit";
            window.location = link;
          }
          else {
            var link = "http://maps.google.com/maps?q=" + $rootScope.lat + "," + $rootScope.lng;
            window.location = link;
          }
        }


        $scope.favorite = function()
        {
          var favorite = 0;
          var favoritelist = localStorageService.get('favorite');
          if($scope.favorited==false)
          {
            if(favoritelist==null)
            {favoritelist="";}
            localStorageService.set('favorite', favoritelist+";"+ $scope.id);
            $scope.favorited=true;
            $ionicPopup.alert({
                template: "Added to My Favorites in options menu",
            });

          }
          else {
            localStorageService.set('favorite', favoritelist.replace(";"+ $scope.id,""));
            $scope.favorited=false;
            $ionicPopup.alert({
                template: "Removed from My Favorites",
            });
          }
          /*var flag = true;
          var reffavorite = new Firebase(refurl+"/favorite");
          reffavorite.orderByChild("userid").equalTo($rootScope.currentUser.uid).once("value", function(snapshot) {
            snapshot.forEach(function(childSnapshot) {
              var key = childSnapshot.key();
              var childData = childSnapshot.val();
              if($scope.id==childData.charityid)
              {
                flag = false;
              }
            })
          });
          if($scope.favorited==false)
          {
          var allfavorite = $firebaseArray(reffavorite);
            allfavorite.$add({userid:$rootScope.currentUser.uid,charityid:$scope.id}).then(function(res) {
              $scope.favorited=true;
              $ionicPopup.alert({
                  template: "This Service have added Your Favorite.",
              });
            });
          }*/
        }
      $scope.showReport = function()
      {
        var mypopup = $ionicPopup.show({
          template: '<textarea ng-model="data.message"></textarea><p class="error">{{data.error}}</p>',
          title: 'Report Service',
          subTitle: null,
          cssClass: 'report',
          scope: $scope,
          buttons: [
            { text: 'Cancel' },
            {
              text: '<b>Send</b>',
              type: 'button-positive',
              onTap: function(e) {
                if (!$scope.data.message) {
                  e.preventDefault();
                  $scope.data.error="Please enter the message you want to communicate to this service";
                } else {
                  var feedbackRef = new Firebase(refurl + "feedback");
                  var allfeedback = $firebaseArray(feedbackRef);
                  allfeedback.$add({
                      message: $scope.data.message,
                      subject: $scope.charity.charityname,
                      createdate: new Date().getTime(),
                      type:2
                    }).then(function(res) {myPopup.close();
                    });
                    $ionicPopup.alert({
                        template: "Message Sent Successfully",
                    });
                    $scope.data.message="";
                  //window.location.href = "mailto:strappdapp@gmail.com?subject=Report "+$scope.charity.charityname+" Charity&body="+$scope.data.message;
                  /*var email = {
                      to: 'ngoctruy87@gmail.com',
                      cc: '',
                      bcc: [],
                      attachments: [],
                      subject: "Report " +$scope.charity.charityname,
                      body: $scope.data.message,
                      isHtml: true
                  };

                  $cordovaEmailComposer.open(email).then(null, function() {
                      // user cancelled email
                  });*/
                  return $scope.data.message;
                }
              }
            }
          ]
        });
      }

    });
});
appControllers.controller('favoriteCtrl', function($cordovaEmailComposer,$ionicFilterBar, $scope, $state, $http, $ionicPopup, $firebaseObject, $stateParams, NgMap, $filter,$firebaseArray,$ionicHistory,$rootScope,$ionicScrollDelegate,localStorageService ){

  $scope.services = [];
  var favoritelist = localStorageService.get('favorite');
  $scope.favorite=[];
  if(favoritelist!=null && favoritelist!="")
  {
    var tmp = favoritelist.substring(1).split(';');
    tmp.forEach(function(id) {
      var ref = new Firebase(refurl + "/charity/" + id);

      ref.once('value', function(charitySnap) {
        var id=charitySnap.key();
        var data = charitySnap.val();
          var obj = {
            charityname: data.charityname,
            service:data.service,
            id:id,
            status:'',
            avaibed:data.avaibed,
            contact:data.contact,
            updateshelter:data.updateshelter
          }
          var myDays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
          if (data.approved == 1) {
              var day = myDays[new Date().getDay()];
              var open = false;

              var till='';
              var until='';
              var timecur = new Date('01/01/2016 ' + $filter('date')(new Date(), 'h:mm a'));
              var datecur = new Date($filter('date')(new Date(), 'MM/dd/yyyy'));
              var nexttime = 999999;
              var nexthour = 999999999;
              var nexttimeobj;
                  data.schedule.forEach(function(schedule) {

                      var timefrom = new Date('01/01/2016 '+ schedule.fromstring);
                      var timeto = new Date('01/01/2016 '+schedule.tostring);

                      var datefrom = new Date(schedule.date);
                      var dateto = new Date(schedule.todate);

                      if (schedule.type == 'Date Range') {
                        obj.search = obj.search+","+schedule.date+" "+schedule.fromstring+" "+schedule.tostring;
                        obj.search = obj.search+","+schedule.todate+" "+schedule.fromstring+" "+schedule.tostring;
                          if (timecur.getTime() >=timefrom.getTime() && timecur.getTime() <= timeto.getTime() &&
                            datefrom.getTime()<= datecur.getTime() && dateto.getTime()>=datecur.getTime()
                          ) {
                              open = true;
                              till = 'till '+schedule.tostring;
                              return;
                          }
                          else if(datefrom.getTime()>=datecur.getTime())
                          {
                            var timeDiff = Math.abs(datefrom.getTime() - datecur.getTime());
                            var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
                            if(diffDays<nexttime)
                            {
                              nexttime = diffDays;
                              nexttimeobj = schedule;
                            }
                          }
                      } else if(schedule.type=='Weekly'){
                          if (schedule.day == day) {
                            obj.search = obj.search+","+schedule.day+" "+schedule.fromstring+" "+schedule.tostring;
                              if (timecur.getTime() >= timefrom.getTime() && timecur.getTime() <= timeto.getTime()) {
                                  open = true;
                                  till = 'till '+schedule.tostring;
                                  return;
                              }
                              else if(timecur.getTime()<timefrom.getTime())
                              {
                                if(nexthour>timefrom.getTime() - timecur.getTime())
                                {
                                  nexttime = 0;
                                  nexthour = timefrom.getTime() - timecur.getTime();
                                  nexttimeobj = schedule;
                                }
                              }
                              else if(timecur.getTime()>timefrom.getTime())
                              {
                                if(nexttime>7)
                                {
                                  nexttime=7;
                                  nexttimeobj = schedule;
                                }
                              }
                          }
                          else if(datecur.getDay()<getday(schedule.day))
                          {
                            if(nexttime> getday(schedule.day)-datecur.getDay())
                            {
                              nexttime = getday(schedule.day)-datecur.getDay();
                              nexttimeobj = schedule;
                            }
                          }
                          else if(datecur.getDay()>getday(schedule.day))
                          {
                            if(nexttime> getday(schedule.day)+7-datecur.getDay())
                            {
                              nexttime = getday(schedule.day)+7-datecur.getDay();
                              nexttimeobj = schedule;
                            }
                          }
                      }
                      else if(schedule.type=='Open 24/7')
                      {
                        open = true;
                        till = '24/7';
                        return;
                      }
                      else if(schedule.type=='Monthly')
                      {
                        var curdate=  new Date();
                        var lstperiod=["First","Second","Third","Fourth","Fifth"];
                        var periodnum = parseInt(curdate.getDate()/7) + (curdate.getDate()%7>0?1:0);
                        var period = lstperiod[periodnum-1];
                        if (schedule.day == day && period == schedule.period) {
                          obj.search = obj.search+","+schedule.day+" "+schedule.fromstring+" "+schedule.tostring;
                            if (timecur.getTime() >= timefrom.getTime() && timecur.getTime() <= timeto.getTime()) {
                                open = true;
                                till = 'till '+schedule.tostring;
                                return;
                            }
                            else if(timecur.getTime()<timefrom.getTime()){
                              nexttime=0;
                              nexttimeobj = schedule;
                            }
                            else if(nexttime>35){
                              nexttime=35;
                              nexttimeobj = schedule;
                            }
                        }
                        else {
                          if(periodnum<getperiod(schedule.period))
                          {
                            if(nexttime>(getperiod(schedule.period)-periodnum)*7)
                            {
                              nexttime = (getperiod(schedule.period)-periodnum)*7;
                              nexttimeobj = schedule;
                            }
                          }
                          else
                          {
                            if(nexttime>(getperiod(schedule.period)+5-periodnum)*7)
                            {
                              nexttime = (getperiod(schedule.period)+5-periodnum)*7;
                              nexttimeobj = schedule;
                            }
                          }
                        }
                      }
                  });
                  //close schedulechildData.schedule.forEach(function(schedule) {
                  if(data.closeschedule!=undefined)
                  {
                  data.closeschedule.forEach(function(schedule) {
                    var timefrom = new Date('01/01/2016 '+ schedule.fromstring);
                    var timeto = new Date('01/01/2016 '+schedule.tostring);

                    var datefrom = new Date(schedule.date);
                    var dateto = new Date(schedule.todate);

                    if (schedule.type == 'Date Range') {
                      obj.search = obj.search+","+schedule.date+" "+schedule.fromstring+" "+schedule.tostring;
                      if(datefrom.getTime()<= datecur.getTime() && dateto.getTime()>datecur.getTime() && schedule.fromstring ==undefined && schedule.tostring==undefined)
                      {
                        open = false;
                        until= "from " + $filter('date')(datefrom, 'MM/dd') +" - "+$filter('date')(dateto, 'MM/dd') +".";
                        return;
                      }
                      else if(datefrom.getTime()== datecur.getTime() && dateto.getTime()==datecur.getTime() && schedule.fromstring ==undefined && schedule.tostring==undefined)
                      {
                        open = false;
                        until= "on " + $filter('date')(datefrom, 'MM/dd') +".";
                        return;
                      }
                      else  if (timecur.getTime() >=timefrom.getTime() && timecur.getTime() <= timeto.getTime() &&
                          datefrom.getTime()<= datecur.getTime() && dateto.getTime()>=datecur.getTime()
                        ) {
                            open = false;
                            until= "till " +schedule.tostring +".";
                            return;
                        }
                    }
                    else if(schedule.type=='Monthly')
                    {
                      var curdate=  new Date();
                      var lstperiod=["First","Second","Third","Fourth","Fifth"];
                      var periodnum = parseInt(curdate.getDate()/7) + (curdate.getDate()%7>0?1:0);
                      var period = lstperiod[periodnum-1];
                      if (schedule.day == day && period == schedule.period) {
                        obj.search = obj.search+","+schedule.day+" "+schedule.fromstring+" "+schedule.tostring;
                          if (timecur.getTime() >= timefrom.getTime() && timecur.getTime() <= timeto.getTime()) {
                              open = false;
                              until= "on "+ getshortordinal(schedule.period) + " "+ getshortday(schedule.day)+" till "  +schedule.tostring +".";
                              return;
                          }
                          else if(schedule.fromstring ==undefined && schedule.tostring==undefined)
                          {
                            open = false;
                            until= "on "+ getshortordinal(schedule.period) + " "+ getshortday(schedule.day)+".";
                            return;
                          }
                          else if(timecur.getTime()< timefrom.getTime() && till=='24/7')
                          {
                            till = "till "+schedule.tostring+".";
                          }
                      }
                    }
                  });
                }
                  obj.status = (open ? "Open "+till+"." : "Closed "+until);
                  if(open==false && nexttimeobj!=undefined && until=='')
                  {
                    if(nexttimeobj.type=="Weekly")
                    {
                      var futureday = myDays[addDays(new Date(),1).getDay()];
                      if(day == nexttimeobj.day)
                      {
                        obj.status = "Closed till " +nexttimeobj.fromstring +".";
                      }
                      else if(futureday == nexttimeobj.day)
                      {
                        obj.status = "Closed until tomorrow " +nexttimeobj.fromstring+".";
                      }
                      else {
                        obj.status = "Closed until "+nexttimeobj.day+" " +nexttimeobj.fromstring+".";
                      }
                    }
                    else if(nexttimeobj.type=="Monthly")
                    {
                      obj.status= "Closed until "+ getshortordinal(nexttimeobj.period) + " "+ getshortday(nexttimeobj.day)+" " +nexttimeobj.fromstring +".";
                    }
                    else if(nexttimeobj.type=="Date Range")
                    {
                      var futureday = addDays(new Date(),1);
                      var strfutureday = $filter('date')(futureday, 'MM/dd/yyyy');
                      if($filter('date')(new Date(), 'MM/dd/yyyy')==nexttimeobj.date)
                      {
                        obj.status= "Closed till "+nexttimeobj.fromstring+".";
                      }
                      else if(strfutureday==nexttimeobj.date){
                      obj.status= "Closed until tomorrow "+nexttimeobj.fromstring+".";
                      }
                      else{
                      obj.status= "Closed until "+ nexttimeobj.date.substring(0,5)+" "+nexttimeobj.fromstring+".";
                    }
                    }
                  }


          }
          var tmpservices = data.service.split(',');
          for(var i=0;i<tmpservices.length;i++)
          {
            if($scope.services.indexOf(tmpservices[i]) === -1) {
              $scope.services.push(tmpservices[i]);
            }
          }
          $scope.favorite.push(obj);
      });
    });
  }
  function addDays(date, days) {
      var result = new Date(date);
      result.setDate(date.getDate() + days);
      return result;
  }
  function getday(day)
  {
    if(day=='Sunday'){
      return 0;
    }else if(day=='Monday')
    {
      return 1;
    }
    else if(day=='Tuesday')
    {
      return 2;
    }
    else if(day=='Wednesday')
    {
      return 3;
    }
    else if(day=='Thursday')
    {
      return 4;
    }
    else if(day=='Friday')
    {
      return 5;
    }
    else if(day=='Saturday')
    {
      return 6;
    }
  }
  function getperiod(period)
  {
    if(period=='First'){
      return 1;
    }else if(period=='Second')
    {
      return 2;
    }
    else if(period=='Third')
    {
      return 3;
    }
    else if(period=='Fourth')
    {
      return 4;
    }
    else if(period=='Fifth')
    {
      return 5;
    }
  }
  function getshortday(day)
  {
    return day;
    if(day=='Monday'){
      return 'Mon';
    }else if(day=='Tuesday')
    {
      return 'Tue';
    }
    else if(day=='Wednesday')
    {
      return 'Wed';
    }
    else if(day=='Thursday')
    {
      return 'Thu';
    }
    else if(day=='Friday')
    {
      return 'Fri';
    }
    else if(day=='Saturday')
    {
      return 'Sat';
    }
    else if(day=='Sunday')
    {
      return 'Sun';
    }
  }
function getshortordinal(ordinal)
{
  if(ordinal=='First'){
    return '1st';
  }else if(ordinal=='Second')
  {
    return '2nd';
  }
  else if(ordinal=='Third')
  {
    return '3rd';
  }
  else if(ordinal=='Fourth')
  {
    return '4th';
  }
  else if(ordinal=='Fifth')
  {
    return '5th';
  }
  else if(ordinal=='Last')
  {
    return 'last';
  }
}
  $scope.showFilterBar = function() {
    //$rootScope.isshowtab = false;
      filterBarInstance = $ionicFilterBar.show({
          items: $scope.favorite,
          update: function(filteredItems, filterText) {
              $scope.favorite = filteredItems;
              if (filterText) {
                  console.log(filterText);
              }
          },
          done: function() {
              var input = document.querySelector("ion-filter-bar input.filter-bar-search");
              if (input) {
                  angular.element(input).attr("placeholder", "Search My Favorites");
              }
          },
          cancel: function(){
            //$rootScope.isshowtab = true;
          }
      });
  };
  $scope.doRefresh = function() {
    $scope.services = ["Food","Shelter","Health","Resources","Work"];
    var favoritelist = localStorageService.get('favorite');
    $scope.favorite=[];
    if(favoritelist!=null && favoritelist!="")
    {
      var tmp = favoritelist.substring(1).split(';');
      tmp.forEach(function(id) {
        var ref = new Firebase(refurl + "/charity/" + id);

        ref.once('value', function(charitySnap) {
          var id=charitySnap.key();
          var data = charitySnap.val();
            var obj = {
              charityname: data.charityname,
              service:data.service,
              id:id,
              status:'',
              avaibed:data.avaibed,
              contact:data.contact,
              updateshelter:data.updateshelter
            }
            var myDays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
            if (data.approved == 1) {
                var day = myDays[new Date().getDay()];
                var open = false;
                var till='';
                var until='';
                var timecur = new Date('01/01/2016 ' + $filter('date')(new Date(), 'h:mm a'));
                var datecur = new Date($filter('date')(new Date(), 'MM/dd/yyyy'));
                var nexttime = 999999;
                var nexthour = 999999999;
                var nexttimeobj;
                    data.schedule.forEach(function(schedule) {

                        var timefrom = new Date('01/01/2016 '+ schedule.fromstring);
                        var timeto = new Date('01/01/2016 '+schedule.tostring);

                        var datefrom = new Date(schedule.date);
                        var dateto = new Date(schedule.todate);

                        if (schedule.type == 'Date Range') {
                          obj.search = obj.search+","+schedule.date+" "+schedule.fromstring+" "+schedule.tostring;
                            if (timecur.getTime() >=timefrom.getTime() && timecur.getTime() <= timeto.getTime() &&
                              datefrom.getTime()<= datecur.getTime() && dateto.getTime()>=datecur.getTime()
                            ) {
                                open = true;
                                till = 'till '+schedule.tostring;
                                return;
                            }
                            else if(datefrom.getTime()>=datecur.getTime())
                            {
                              var timeDiff = Math.abs(datefrom.getTime() - datecur.getTime());
                              var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
                              if(diffDays<nexttime)
                              {
                                nexttime = diffDays;
                                nexttimeobj = schedule;
                              }
                            }
                        } else if(schedule.type=='Weekly'){
                            if (schedule.day == day) {
                              obj.search = obj.search+","+schedule.day+" "+schedule.fromstring+" "+schedule.tostring;
                                if (timecur.getTime() >= timefrom.getTime() && timecur.getTime() <= timeto.getTime()) {
                                    open = true;
                                    till = 'till '+schedule.tostring;
                                    return;
                                }
                                else if(timecur.getTime()<timefrom.getTime())
                                {
                                  if(nexthour>timefrom.getTime() - timecur.getTime())
                                  {
                                    nexttime = 0;
                                    nexthour = timefrom.getTime() - timecur.getTime();
                                    nexttimeobj = schedule;
                                  }
                                }
                                else if(timecur.getTime()>timefrom.getTime())
                                {
                                  if(nexttime>7)
                                  {
                                    nexttime=7;
                                    nexttimeobj = schedule;
                                  }
                                }
                            }
                            else if(datecur.getDay()<getday(schedule.day))
                            {
                              if(nexttime> getday(schedule.day)-datecur.getDay())
                              {
                                nexttime = getday(schedule.day)-datecur.getDay();
                                nexttimeobj = schedule;
                              }
                            }
                            else if(datecur.getDay()>getday(schedule.day))
                            {
                              if(nexttime> getday(schedule.day)+7-datecur.getDay())
                              {
                                nexttime = getday(schedule.day)+7-datecur.getDay();
                                nexttimeobj = schedule;
                              }
                            }
                        }
                        else if(schedule.type=='Open 24/7')
                        {
                          open = true;
                          till = '24/7';
                          return;
                        }
                        else if(schedule.type=='Monthly')
                        {
                          var curdate=  new Date();
                          var lstperiod=["First","Second","Third","Fourth","Fifth"];
                          var periodnum = parseInt(curdate.getDate()/7) + (curdate.getDate()%7>0?1:0);
                          var period = lstperiod[periodnum-1];
                          if (schedule.day == day && period == schedule.period) {
                            obj.search = obj.search+","+schedule.day+" "+schedule.fromstring+" "+schedule.tostring;
                              if (timecur.getTime() >= timefrom.getTime() && timecur.getTime() <= timeto.getTime()) {
                                  open = true;
                                  till = 'till '+schedule.tostring;
                                  return;
                              }
                              else if(timecur.getTime()<timefrom.getTime()){
                                nexttime=0;
                                nexttimeobj = schedule;
                              }
                              else if(nexttime>35){
                                nexttime=35;
                                nexttimeobj = schedule;
                              }
                          }
                          else {
                            if(periodnum<getperiod(schedule.period))
                            {
                              if(nexttime>(getperiod(schedule.period)-periodnum)*7)
                              {
                                nexttime = (getperiod(schedule.period)-periodnum)*7;
                                nexttimeobj = schedule;
                              }
                            }
                            else
                            {
                              if(nexttime>(getperiod(schedule.period)+5-periodnum)*7)
                              {
                                nexttime = (getperiod(schedule.period)+5-periodnum)*7;
                                nexttimeobj = schedule;
                              }
                            }
                          }
                        }
                    });
                    //close schedulechildData.schedule.forEach(function(schedule) {
                    if(data.closeschedule!=undefined)
                    {
                    data.closeschedule.forEach(function(schedule) {
                      var timefrom = new Date('01/01/2016 '+ schedule.fromstring);
                      var timeto = new Date('01/01/2016 '+schedule.tostring);

                      var datefrom = new Date(schedule.date);
                      var dateto = new Date(schedule.todate);

                      if (schedule.type == 'Date Range') {
                        obj.search = obj.search+","+schedule.date+" "+schedule.fromstring+" "+schedule.tostring;
                        if(datefrom.getTime()<= datecur.getTime() && dateto.getTime()>datecur.getTime() && schedule.fromstring ==undefined && schedule.tostring==undefined)
                        {
                          open = false;
                          until= "from " + $filter('date')(datefrom, 'MM/dd') +" - "+$filter('date')(dateto, 'MM/dd') +".";
                          return;
                        }
                        else if(datefrom.getTime()== datecur.getTime() && dateto.getTime()==datecur.getTime() && schedule.fromstring ==undefined && schedule.tostring==undefined)
                        {
                          open = false;
                          until= "on " + $filter('date')(datefrom, 'MM/dd') +".";
                          return;
                        }
                        else  if (timecur.getTime() >=timefrom.getTime() && timecur.getTime() <= timeto.getTime() &&
                            datefrom.getTime()<= datecur.getTime() && dateto.getTime()>=datecur.getTime()
                          ) {
                              open = false;
                              until= "till " +schedule.tostring +".";
                              return;
                          }
                      }
                      else if(schedule.type=='Monthly')
                      {
                        var curdate=  new Date();
                        var lstperiod=["First","Second","Third","Fourth","Fifth"];
                        var periodnum = parseInt(curdate.getDate()/7) + (curdate.getDate()%7>0?1:0);
                        var period = lstperiod[periodnum-1];
                        if (schedule.day == day && period == schedule.period) {
                          obj.search = obj.search+","+schedule.day+" "+schedule.fromstring+" "+schedule.tostring;
                            if (timecur.getTime() >= timefrom.getTime() && timecur.getTime() <= timeto.getTime()) {
                                open = false;
                                until= "on "+ getshortordinal(schedule.period) + " "+ getshortday(schedule.day)+" till "  +schedule.tostring +".";
                                return;
                            }
                            else if(schedule.fromstring ==undefined && schedule.tostring==undefined)
                            {
                              open = false;
                              until= "on "+ getshortordinal(schedule.period) + " "+ getshortday(schedule.day)+".";
                              return;
                            }
                            else if(timecur.getTime()< timefrom.getTime() && till=='24/7')
                            {
                              till = "till "+schedule.tostring+".";
                            }
                        }
                      }
                    });
                  }
                    obj.status = (open ? "Open "+till+"." : "Closed "+until);
                    if(open==false && nexttimeobj!=undefined && until=='')
                    {
                      if(nexttimeobj.type=="Weekly")
                      {
                        var futureday = myDays[addDays(new Date(),1).getDay()];
                        if(day == nexttimeobj.day)
                        {
                          obj.status = "Closed till " +nexttimeobj.fromstring +".";
                        }
                        else if(futureday == nexttimeobj.day)
                        {
                          obj.status = "Closed until tomorrow " +nexttimeobj.fromstring+".";
                        }
                        else {
                          obj.status = "Closed until "+nexttimeobj.day+" " +nexttimeobj.fromstring+".";
                        }
                      }
                      else if(nexttimeobj.type=="Monthly")
                      {
                        obj.status= "Closed until "+ getshortordinal(nexttimeobj.period) + " "+ getshortday(nexttimeobj.day)+" " +nexttimeobj.fromstring +".";
                      }
                      else if(nexttimeobj.type=="Date Range")
                      {
                        var futureday = addDays(new Date(),1);
                        var strfutureday = $filter('date')(futureday, 'MM/dd/yyyy');
                        if($filter('date')(new Date(), 'MM/dd/yyyy')==nexttimeobj.date)
                        {
                          obj.status= "Closed till "+nexttimeobj.fromstring+".";
                        }
                        else if(strfutureday==nexttimeobj.date){
                        obj.status= "Closed until tomorrow "+nexttimeobj.fromstring+".";
                        }
                        else{
                        obj.status= "Closed until "+ nexttimeobj.date.substring(0,5)+" " +nexttimeobj.fromstring+".";
                      }
                      }
                    }
            }
            $scope.favorite.push(obj);
        });
      });
    }
    $scope.$broadcast('scroll.refreshComplete');

  };
  $scope.showServiceDetails = function(item)
  {
    $rootScope.beforestate = "Favorites";
    $state.go('detail', {
        'id': item.id
    });
  }
  $scope.removeFromFavorites = function(item,idx)
  {
    var favoritelist = localStorageService.get('favorite');
    localStorageService.set('favorite', favoritelist.replace(";"+item.id,""));
    var myEl = angular.element( document.querySelector( '#favorite-'+idx ) );
    myEl.remove();
  }
});
