
appControllers.controller('charityCtrl',
    function($rootScope,$scope, $state, $http, $ionicPopup, $firebaseArray, $stateParams, $ionicLoading,
        $timeout, $ionicFilterBar,$filter,NgMap,$ionicTabsDelegate,$ionicScrollDelegate,localStorageService,$ionicModal ) {
          var vm = this;
          vm.positions = [];
          vm.distancemin = 0;
          NgMap.getMap().then(function(map) {
            vm.map = map;
          });

          vm.clicked = function() {
             alert('Clicked a link inside infoWindow');
           };
          vm.showDetail = function(e, shop) {
            vm.shop = shop;
            vm.map.showInfoWindow('foo-iw', shop.id);
          };

          vm.hideDetail = function() {
            vm.map.hideInfoWindow('foo-iw');
          };
          $rootScope.currentTab = $stateParams.service;
          $scope.gotoCrisis = function()
          {
            $state.go("Crisis");
          }
          $ionicModal.fromTemplateUrl('templates/charity/html/location.html', {
              scope: $scope,
              animation: 'slide-in-up'
          }).then(function(modal) {
            if($scope.modal == undefined)
            {
              $scope.modal = modal;
              $rootScope.modalcity = modal;
              if($rootScope.allowlocation==false && $rootScope.currentlocation.length==0)
              {
                $scope.modal.show();
              }
            }
          });
          $scope.cleaninput=function(){
            $scope.filter.location = "";
          }
          $scope.openModal = function() {
              $scope.modal.show();
          };
          $scope.closeModal = function() {
              $scope.modal.hide();
          };

          $scope.checkisnumber = function()
          {
            var numbers = new RegExp(/^[0-9]+$/);
            var code = $scope.filter.charityname;
            if(numbers.test(code)){
                return true;
            }
            else{
                return false;
            }
          }
          $scope.setlocation=function(location,lat,lng)
          {
            $scope.filter.location=location;
            $rootScope.currentlocation = ""+location;
            
            console.log($rootScope.currentlocation);
            localStorageService.set('currentlocation', ""+location);
            $scope.modal.hide();
            $rootScope.$broadcast('eventreload', {
                gender: $rootScope.Gender
            });
          }
          $scope.GetCurrentLocation=function()
          {
            $scope.filter.location="";
            if (navigator.geolocation) navigator.geolocation.getCurrentPosition(onPositionUpdate);

            function onPositionUpdate(position) {
                $rootScope.lat = position.coords.latitude;
                $rootScope.lng = position.coords.longitude;

                $rootScope.currentlocation="Current Location";
                localStorageService.remove('currentlocation');
                $scope.modal.hide();
                $rootScope.$broadcast('eventreload', {
                    gender: $rootScope.Gender
                });
            }

          }
        $scope.$on('$ionicView.beforeEnter', function() {
            $scope.servicename = $stateParams.service;
            $scope.filter = {};
            $scope.data = {};
            $scope.filter.charityname = '';
            $scope.filter.location = $rootScope.currentlocation;
            $scope.charity = [];
            $scope.charityall = [];
            $scope.city =[];
            $scope.zip =[];
            $scope.lat = "";
            $scope.lng = "";
            if($rootScope.pageindex==undefined)
            {
              $rootScope.pageindex=1;
            }
            $scope.limit = $rootScope.pageindex * 10;
            var myDays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
            $ionicLoading.show({
                template: 'Loading...'
            });

            if (navigator.geolocation) navigator.geolocation.getCurrentPosition(onPositionUpdate);

            function onPositionUpdate(position) {
              console.log( position.coords.latitude);
                $rootScope.lat = position.coords.latitude;
                $rootScope.lng = position.coords.longitude;
            }

            var citykeys=[];
            var zipkeys=[];
            var ref = new Firebase(refurl);
            ref.child('charity')
                //.orderByChild('service')
                //.equalTo($scope.servicename)
                .once('value', function(charitySnap) {
                    $ionicLoading.hide().then(function() {});
                    charitySnap.forEach(function(childSnapshot) {

                        var key = childSnapshot.key();
                        var childData = childSnapshot.val();
                        var obj = {
                            id: key,
                            avaibed:childData.avaibed,
                            charityname: childData.charityname,
                            email:childData.email,
                            phone:childData.phone,
                            userid: childData.userid,
                            service: childData.service,
                            category: childData.category.replace(/,/g,', '),
                            fulladdress: childData.address1 + ", " + childData.city + ", " + childData.state,
                            lat: childData.lat,
                            lng: childData.lng,
                            city:childData.city,
                            zip:childData.zip,
                            distance: "",
                            distancenumber:0,
                            status: "",
                            open:false,
                            pos:[],
                            servicetype:childData.servicetype,
                            kudos: childData.kudos==undefined?0:parseInt(childData.kudos),
                            showflag:childData.showflag,
                            showdonate: childData.showdonate,
                            age:childData.Age,
                            closed:false,
                            contact:childData.contact,
                            updateshelter:childData.updateshelter,
                            search: childData.charityname+","+childData.servicetype+","+childData.city+","+childData.zip+""+childData.description+","+childData.Age+","+childData.email+","+childData.website+","+childData.phone+","+childData.address+","+childData.state
                        }
                        //luu ds city or zip
                        if(citykeys.indexOf(childData.city) === -1) {
                            citykeys.push(childData.city);
                            var objnew ={city:childData.city,zip:childData.zip,state:childData.state,search:childData.city+", "+childData.state,lat:childData.lat,lng:childData.lng};
                            $scope.city.push(objnew);
                        }
                        if(zipkeys.indexOf(childData.zip) === -1) {
                            zipkeys.push(childData.zip);
                            //var objnew ={city:childData.city,zip:childData.zip};
                            var objnew ={city:childData.city,zip:childData.zip,state:childData.state,search:childData.city+", "+childData.state,lat:childData.lat,lng:childData.lng};
                            $scope.zip.push(objnew);
                        }

                        if (childData.approved == 1) {
                            var day = myDays[new Date().getDay()];
                            var open = false;
                            var show = true;
                            var till='';
                            var until='';
                            var timecur = new Date('01/01/2016 ' + $filter('date')(new Date(), 'h:mm a'));
                            var datecur = new Date($filter('date')(new Date(), 'MM/dd/yyyy'));
                            var nexttime = 999999;
                            var nexthour = 999999999;
                            var nexttimeobj;
                            var opentime = 0;
                            var openday = 0;
                            var opentimeto ="";
                            if(childData.schedule!=undefined)
                            {
                                childData.schedule.forEach(function(schedule) {

                                  if(obj.id=='-KeoA0v_OEVbOr74MH46')
                                  {
                                    debugger;
                                    console.log('-KeoA0v_OEVbOr74MH46');
                                  }

                                    var timefrom = new Date('01/01/2016 '+ schedule.fromstring);
                                    var timeto = new Date('01/01/2016 '+schedule.tostring);

                                    var datefrom = new Date(schedule.date);
                                    var dateto = new Date(schedule.todate);

                                    if (schedule.type == 'Date Range') {
                                      obj.search = obj.search+","+schedule.date+" "+schedule.fromstring+" "+schedule.tostring;
                                      obj.search = obj.search+","+schedule.todate+" "+schedule.fromstring+" "+schedule.tostring;
                                        if (timecur.getTime() >=timefrom.getTime() && timecur.getTime() <= timeto.getTime() &&
                                          datefrom.getTime()<= datecur.getTime() && dateto.getTime()>=datecur.getTime()
                                        ) {
                                            open = true;
                                            till = 'till '+schedule.tostring;
                                            return;
                                        }
                                        else if(datefrom.getTime()>=datecur.getTime())
                                        {
                                          var timeDiff = Math.abs(datefrom.getTime() - datecur.getTime());
                                          var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
                                          if(diffDays<nexttime)
                                          {
                                            nexttime = diffDays;
                                            nexttimeobj = schedule;
                                          }
                                        }
                                    } else if(schedule.type=='Weekly'){
                                        if (schedule.day == day) {
                                          obj.search = obj.search+","+schedule.day+" "+schedule.fromstring+" "+schedule.tostring;
                                            if (timecur.getTime() >= timefrom.getTime() && timecur.getTime() <= timeto.getTime()) {
                                                open = true;
                                                till = 'till '+schedule.tostring;
                                                opentime = timeto.getTime();
                                                openday = getday(schedule.day);
                                                opentimeto = schedule.tostring;
                                            }
                                            else if(opentimeto=='11:59 PM' && schedule.fromstring =='12:00 AM'){
                                              open = true;
                                              till = 'till '+schedule.tostring;
                                            }
                                            else if(timecur.getTime()<timefrom.getTime())
                                            {
                                              if(nexthour>timefrom.getTime() - timecur.getTime())
                                              {
                                                nexttime = 0;
                                                nexthour = timefrom.getTime() - timecur.getTime();
                                                nexttimeobj = schedule;
                                                until='till '+schedule.fromstring;
                                                if(open==true && opentime+70000>timefrom.getTime())
                                                {
                                                  till ='till '+schedule.tostring;
                                                }
                                              }
                                            }
                                            else if(timecur.getTime()>timefrom.getTime())
                                            {
                                              if(nexttime>7)
                                              {
                                                nexttime=7;
                                                nexttimeobj = schedule;
                                              }
                                            }
                                        }
                                        else if(datecur.getDay()<getday(schedule.day))
                                        {
                                          if(nexttime> getday(schedule.day)-datecur.getDay())
                                          {
                                            nexttime = getday(schedule.day)-datecur.getDay();
                                            nexttimeobj = schedule;
                                          }
                                        }
                                        else if(datecur.getDay()>getday(schedule.day))
                                        {
                                          if(nexttime> getday(schedule.day)+7-datecur.getDay())
                                          {
                                            nexttime = getday(schedule.day)+7-datecur.getDay();
                                            nexttimeobj = schedule;
                                          }
                                        }
                                    }
                                    else if(schedule.type=='Open 24/7')
                                    {
                                      open = true;
                                      till = '24/7';
                                      return;
                                    }
                                    else if(schedule.type=='Monthly')
                                    {
                                      if(obj.id=="-KeoA0v_OEVbOr74MH46")
                                    {
                                      console.log('test');
                                    }
                                      var curdate=  new Date();
                                      var lstperiod=["First","Second","Third","Fourth","Fifth"];
                                      var periodnum = parseInt(curdate.getDate()/7) + (curdate.getDate()%7>0?1:0);
                                      var period = lstperiod[periodnum-1];
                                      if (schedule.day == day && period == schedule.period) {
                                        obj.search = obj.search+","+schedule.day+" "+schedule.fromstring+" "+schedule.tostring;
                                          if (timecur.getTime() >= timefrom.getTime() && timecur.getTime() <= timeto.getTime()) {
                                              open = true;
                                              till = 'till '+schedule.tostring;
                                              return;
                                          }
                                          else if(timecur.getTime()<timefrom.getTime()){
                                            nexttime=0;
                                            nexttimeobj = schedule;
                                          }
                                          else if(nexttime>35){
                                            nexttime=35;
                                            nexttimeobj = schedule;
                                          }
                                      }
                                      else if(schedule.period=='Last' && schedule.day == day && datecur.getDate() == GetDateofLastDay(schedule.day).getDate())
                                      {
                                        if (timecur.getTime() >= timefrom.getTime() && timecur.getTime() <= timeto.getTime()) {
                                            open = true;
                                            till = 'till '+schedule.tostring;
                                            return;
                                        }
                                        else if(timecur.getTime()<timefrom.getTime()){
                                          nexttime=0;
                                          nexttimeobj = schedule;
                                        }
                                        else if(nexttime>GetDateofLastDay(schedule.day).getDate()){
                                          nexttime=GetDateofLastDay(schedule.day).getDate();
                                          nexttimeobj = schedule;
                                        }
                                      }
                                      else if(schedule.period=='Last')
                                      {
                                        until= "until Last"+ " "+ getshortday(schedule.day)+" "  +schedule.fromstring +".";
                                      }
                                      else {
                                        if(periodnum<getperiod(schedule.period))
                                        {
                                          if(nexttime>(getperiod(schedule.period)-periodnum)*7)
                                          {
                                            nexttime = (getperiod(schedule.period)-periodnum)*7;
                                            nexttimeobj = schedule;
                                          }
                                        }
                                        else
                                        {
                                          if(nexttime>(getperiod(schedule.period)+5-periodnum)*7)
                                          {
                                            nexttime = (getperiod(schedule.period)+5-periodnum)*7;
                                            nexttimeobj = schedule;
                                          }
                                        }
                                      }
                                    }
                                });
                                }
                                //close schedulechildData.schedule.forEach(function(schedule) {
                                if(childData.closeschedule!=undefined)
                                {
                                childData.closeschedule.forEach(function(schedule) {
                                    var timefrom = new Date('01/01/2016 '+ schedule.fromstring);
                                    var timeto = new Date('01/01/2016 '+schedule.tostring);

                                    var datefrom = new Date(schedule.date);
                                    var dateto = new Date(schedule.todate);
                                    if(schedule.type=='Permanently Closed')
                                    {
                                      obj.closed=true;
                                    }
                                    else if (schedule.type == 'Date Range') {
                                      obj.search = obj.search+","+schedule.date+" "+schedule.fromstring+" "+schedule.tostring;
                                      if(datefrom.getTime()<= datecur.getTime() && dateto.getTime()>datecur.getTime() && schedule.fromstring ==undefined && schedule.tostring==undefined)
                                      {
                                        open = false;
                                        until= "from " + $filter('date')(datefrom, 'MM/dd') +" - "+$filter('date')(dateto, 'MM/dd') +".";
                                        return;
                                      }
                                      else if(datefrom.getTime()== datecur.getTime() && dateto.getTime()==datecur.getTime() && schedule.fromstring ==undefined && schedule.tostring==undefined)
                                      {
                                        open = false;
                                        until= "until " + $filter('date')(datefrom, 'MM/dd') +".";
                                        return;
                                      }
                                      else  if (timecur.getTime() >=timefrom.getTime() && timecur.getTime() <= timeto.getTime() &&
                                          datefrom.getTime()<= datecur.getTime() && dateto.getTime()>=datecur.getTime()
                                        ) {
                                            open = false;
                                            until= "till " +schedule.tostring +".";
                                            return;
                                        }
                                    }
                                    else if(schedule.type=='Weekly'){
                                        if (schedule.day == day) {
                                            open = false;
                                            until = 'on '+schedule.day;
                                            return;
                                        }
                                    }
                                    else if(schedule.type=='Monthly')
                                    {

                                      var curdate=  new Date();
                                      var lstperiod=["First","Second","Third","Fourth","Fifth"];
                                      var periodnum = parseInt(curdate.getDate()/7) + (curdate.getDate()%7>0?1:0);
                                      var period = lstperiod[periodnum-1];
                                      if (schedule.day == day && period == schedule.period) {
                                        obj.search = obj.search+","+schedule.day+" "+schedule.fromstring+" "+schedule.tostring;
                                          if (timecur.getTime() >= timefrom.getTime() && timecur.getTime() <= timeto.getTime()) {
                                              open = false;
                                              until= "until "+ getshortordinal(schedule.period) + " "+ getshortday(schedule.day)+" till "  +schedule.tostring +".";
                                              return;
                                          }
                                          else if(schedule.fromstring ==undefined && schedule.tostring==undefined)
                                          {
                                            open = false;
                                            until= "until "+ getshortordinal(schedule.period) + " "+ getshortday(schedule.day)+".";
                                            return;
                                          }
                                          else if(timecur.getTime()< timefrom.getTime() && till=='24/7')
                                          {
                                            till = "till "+schedule.tostring+".";
                                          }
                                      }
                                      else if(schedule.period=='Last' && schedule.day == day && datecur.getDate() == GetDateofLastDay(schedule.day).getDate())
                                      {
                                        if (timecur.getTime() >= timefrom.getTime() && timecur.getTime() <= timeto.getTime()) {
                                            open = false;
                                            until= "until "+ getshortordinal(schedule.period) + " "+ getshortday(schedule.day)+" till "  +schedule.tostring +".";
                                            return;
                                        }
                                        else if(schedule.fromstring ==undefined && schedule.tostring==undefined)
                                        {
                                          open = false;
                                          until= "until "+ getshortordinal(schedule.period) + " "+ getshortday(schedule.day)+".";
                                          return;
                                        }
                                        else if(timecur.getTime()< timefrom.getTime() && till=='24/7')
                                        {
                                          till = "till "+schedule.tostring+".";
                                        }
                                      }
                                    }
                                });
                              }
                              if(obj.id=='-KfbXQcwMJuiyYqUC4BX')
                            {
                              console.log('-KfbXQcwMJuiyYqUC4BX');
                            }
                            if (show) {
                                obj.status = (open ? "Open "+till+"." : "Closed "+until);
                                if(obj.contact==true)
                              {
                                obj.status="";
                              }
                                obj.open = open;
                                if(obj.open==false && nexttimeobj!=undefined && until=='')
                                {
                                  if(nexttimeobj.type=="Weekly")
                                  {
                                    var futureday = myDays[addDays(new Date(),1).getDay()];
                                    if(day == nexttimeobj.day)
                                    {
                                      obj.status = "Closed till " +nexttimeobj.fromstring +" Next "+day+".";
                                    }
                                    else if(futureday == nexttimeobj.day)
                                    {
                                      obj.status = "Closed until tomorrow " +nexttimeobj.fromstring+".";
                                    }
                                    else {
                                      obj.status = "Closed until "+nexttimeobj.day+" "  +nexttimeobj.fromstring+".";
                                    }
                                  }
                                  else if(nexttimeobj.type=="Monthly")
                                  {
                                    obj.status= "Closed until "+ getshortordinal(nexttimeobj.period) + " "+ getshortday(nexttimeobj.day)+" "  +nexttimeobj.fromstring +".";
                                  }
                                  else if(nexttimeobj.type=="Date Range")
                                  {
                                    var futureday = addDays(new Date(),1);
                                    var strfutureday = $filter('date')(futureday, 'MM/dd/yyyy');
                                    if($filter('date')(new Date(), 'MM/dd/yyyy')==nexttimeobj.date)
                                    {
                                      obj.status= "Closed till "+nexttimeobj.fromstring+".";
                                    }
                                    else if(strfutureday==nexttimeobj.date){
                                    obj.status= "Closed until tomorrow "+nexttimeobj.fromstring+".";
                                    }
                                    else{
                                    obj.status= "Closed until "+ nexttimeobj.date.substring(0,5) +" "+nexttimeobj.fromstring+".";
                                  }
                                  }
                                }
                                obj.pos = [obj.lat,obj.lng];
                                var distance;
                                if ($rootScope.lat && $rootScope.lng && obj.lat != undefined && obj.lng != undefined) {
                                  distance = (getDistanceFromLatLonInKm($rootScope.lat,$rootScope.lng,obj.lat,obj.lng)*0.621371192).toFixed(1);
                                  obj.distance = distance +" Miles";
                                  obj.distancenumber = parseFloat(distance);
                                }
                                if (($rootScope.currentlocation==obj.city || $rootScope.currentlocation==obj.zip || $rootScope.currentlocation=="Current Location" || $rootScope.currentlocation=="") && childData.service.indexOf($scope.servicename)!=-1 && ($rootScope.open == open || $rootScope.open==false) && ((childData.category.indexOf($rootScope.Gender) != -1 && childData.category.indexOf('All') == -1) || $rootScope.Gender == 'All')) {
                                  if($rootScope.topkudos==true && obj.distancenumber<50)
                                  {
                                    $scope.charity.push(obj);
                                  }
                                  else if($rootScope.topkudos==false){
                                    $scope.charity.push(obj);
                                  }
                                    if(vm.distancemin == 0 || vm.distancemin>distance)
                                    {
                                      vm.distancemin = distance;
                                      vm.lat = obj.lat;
                                      vm.lng = obj.lng;
                                    }
                                }
                                $scope.charityall.push(obj);

                            }
                        }
                        $rootScope.shownote=true;
                    })

                });

                if($rootScope.scrollHeight)
                {
                  $ionicScrollDelegate.scrollTo(0, $rootScope.scrollHeight);
                }
        });
        function GetDateofLastDay(days)
        {
          var date = new Date();
          var myDays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
          var lastdate = new Date(date.getFullYear(), date.getMonth()+1, 0);
          for(var i = lastdate.getDate(); i>0;i--)
          {
            var d = new Date(date.getFullYear(),date.getMonth(),i);
            if(days == myDays[d.getDay()])
            {
              return d;
            }
          }
        }
        function addDays(date, days) {
            var result = new Date(date);
            result.setDate(date.getDate() + days);
            return result;
        }
        function getday(day)
        {
          if(day=='Sunday'){
            return 0;
          }else if(day=='Monday')
          {
            return 1;
          }
          else if(day=='Tuesday')
          {
            return 2;
          }
          else if(day=='Wednesday')
          {
            return 3;
          }
          else if(day=='Thursday')
          {
            return 4;
          }
          else if(day=='Friday')
          {
            return 5;
          }
          else if(day=='Saturday')
          {
            return 6;
          }
        }
        function getperiod(period)
        {
          if(period=='First'){
            return 1;
          }else if(period=='Second')
          {
            return 2;
          }
          else if(period=='Third')
          {
            return 3;
          }
          else if(period=='Fourth')
          {
            return 4;
          }
          else if(period=='Fifth')
          {
            return 5;
          }
        }
        function getshortday(day)
        {
          return day;
          if(day=='Monday'){
            return 'Mon';
          }else if(day=='Tuesday')
          {
            return 'Tue';
          }
          else if(day=='Wednesday')
          {
            return 'Wed';
          }
          else if(day=='Thursday')
          {
            return 'Thu';
          }
          else if(day=='Friday')
          {
            return 'Fri';
          }
          else if(day=='Saturday')
          {
            return 'Sat';
          }
          else if(day=='Sunday')
          {
            return 'Sun';
          }
        }
      function getshortordinal(ordinal)
      {
        if(ordinal=='First'){
          return '1st';
        }else if(ordinal=='Second')
        {
          return '2nd';
        }
        else if(ordinal=='Third')
        {
          return '3rd';
        }
        else if(ordinal=='Fourth')
        {
          return '4th';
        }
        else if(ordinal=='Fifth')
        {
          return '5th';
        }
        else if(ordinal=='Last')
        {
          return 'last';
        }
      }
        $scope.loadmore = function(){
          if($rootScope.pageindex==undefined)
          {$rootScope.pageindex=1;}
          $rootScope.pageindex = $rootScope.pageindex+1;
          $scope.limit = $rootScope.pageindex*10;
        }
        $scope.$on('eventreload', function(event, args) {
          $ionicScrollDelegate.scrollTop();
            NgMap.getMap().then(function(map) {
              vm.map = map;
            });
            console.log('');
            vm.distancemin =0;
            $scope.charity = [];
            var reffavorite = new Firebase(refurl+"/favorite");
            debugger;
            $scope.charityall.forEach(function(childData) {
              var flagsearch = false;
              if($rootScope.keyword!='')
              {
                $rootScope.keyword.split(',').forEach(function(skey){
                  var tmp = $filter('lowercase')(childData.servicetype);
                  if(tmp.indexOf(skey)!=-1)
                  {
                    flagsearch = true;
                  }
                });
              }
              else if($rootScope.keyword=='')
              {
                flagsearch = true;
              }
                if (($rootScope.currentlocation==childData.city || $rootScope.currentlocation==childData.zip || $rootScope.currentlocation=="Current Location") && flagsearch==true && childData.service.indexOf($scope.servicename)!=-1 && ($rootScope.open==childData.open || $rootScope.open == false) && ((childData.category.indexOf($rootScope.Gender) != -1 && childData.category.indexOf('All')== -1)  || $rootScope.Gender == 'All'))
                {
                  if($rootScope.lat && $rootScope.lng)
                  {
                    var distance;
                    if (childData.lat != undefined && childData.lng != undefined) {
                      distance = (getDistanceFromLatLonInKm($rootScope.lat,$rootScope.lng,childData.lat,childData.lng)*0.621371192).toFixed(1);
                      childData.distance = distance +" Miles";
                      childData.distancenumber = parseFloat(distance);
                    }
                    if(vm.distancemin == 0 || vm.distancemin>distance)
                    {
                      vm.distancemin = distance;
                      vm.lat = childData.lat;
                      vm.lng = childData.lng;
                    }
                  }
                  else {
                    childData.distance="";
                    childData.distancenumber=0;
                  }
                  if($rootScope.favorite == true)
                  {
                    reffavorite.orderByChild("userid").equalTo($rootScope.currentUser.uid).once("value", function(snapshot) {
                      snapshot.forEach(function(childSnapshot) {
                        var key = childSnapshot.key();
                        var favoData = childSnapshot.val();
                        if(childData.id==favoData.charityid)
                        {
                          $scope.charity.push(childData);
                        }
                      })
                    });
                  }
                  else if($rootScope.topkudos==true && childData.distancenumber<50)
                  {
                    $scope.charity.push(childData);
                  }
                  else if($rootScope.topkudos==false){
                    $scope.charity.push(childData);
                  }

                }
            });
        });

        $rootScope.ReloadListItem=function(service,idx)
        {
          $ionicTabsDelegate.select(idx, false);
          $scope.servicename = service;
          NgMap.getMap().then(function(map) {
            vm.map = map;
          });
          $rootScope.currentTab=service;

          vm.distancemin =0;
          $scope.charity = [];
          $scope.charityall.forEach(function(childData) {
              if (($rootScope.currentlocation==childData.city || $rootScope.currentlocation==childData.zip || $rootScope.currentlocation=="Current Location") && childData.service.indexOf(service)!=-1 && ($rootScope.open==childData.open || $rootScope.open == false) && ((childData.category.indexOf($rootScope.Gender) != -1 && childData.category.indexOf('All') == -1) || $rootScope.Gender == 'All')) {
                if($rootScope.data!= undefined)
                {
                  var distance;
                  if (childData.lat != undefined && childData.lng != undefined) {
                    distance = (getDistanceFromLatLonInKm($rootScope.data.lat,$rootScope.data.lng,childData.lat,childData.lng)*0.621371192).toFixed(1);
                    childData.distance = distance +" Miles";
                    childData.distancenumber = parseFloat(distance);
                  }
                }
                if(vm.distancemin == 0 || vm.distancemin>distance)
                {
                  vm.distancemin = distance;
                  vm.lat = childData.lat;
                  vm.lng = childData.lng;
                }
                if($rootScope.topkudos==true && childData.distancenumber<50)
                {
                  $scope.charity.push(childData);
                }
                else if($rootScope.topkudos==false){
                  $scope.charity.push(childData);
                }

              }
          });
        }
        $scope.detail = function(event,id,index) {
          if(event.target.tagName!="A" && event.target.tagName!="I")
            var scrollHeight = 0;
            for (var i = 0; i < index; i++) {
              scrollHeight += document.getElementById('charity' + index).offsetHeight;
            }
            $rootScope.scrollHeight = scrollHeight;

            $rootScope.beforestate = "Services";
          $state.go('detail', {
              'id': id
          });

        };
        function getDistanceFromLatLonInKm(lat1, lon1, lat2, lon2) {
            var R = 6371; // Radius of the earth in km
            var dLat = deg2rad(lat2 - lat1); // deg2rad below
            var dLon = deg2rad(lon2 - lon1);
            var a =
                Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
                Math.sin(dLon / 2) * Math.sin(dLon / 2);
            var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
            var d = R * c; // Distance in km
            return d;
        }
        function deg2rad(deg) {
            return deg * (Math.PI / 180)
        }
        function getLatitudeLongitude(callback, address) {
            // Initialize the Geocoder
            geocoder = new google.maps.Geocoder();
            if (geocoder) {
                geocoder.geocode({
                    'address': address
                }, function(results, status) {
                    if (status == google.maps.GeocoderStatus.OK) {
                        callback(results[0]);
                    }
                });
            }
        }
        $scope.removeCharity = function(obj,idx) {
            var fredRef = new Firebase(refurl + "/charity/" + obj.id);

            var confirmPopup = $ionicPopup.confirm({
                title: "",
                template: 'Do you want to Delete this Service?',
                cancelText: 'No',
                okText: 'Yes'
            }).then(function(res) {
              if (res) {
                var onComplete = function(error) {
                    if (error) {
                        alert(error);
                    } else {
                        //var index = $scope.charity.indexOf(obj);
                        //$scope.charity.splice(index, 1);
                        var myEl = angular.element( document.querySelector( '#charity'+idx ) );
                        myEl.remove();
                        $ionicPopup.alert({
                            title: "",
                            template: "Service Deleted Successfully",
                        });
                    }
                };
                fredRef.remove(onComplete);
            }
            })


        }
        $scope.editCharity = function(obj) {
            $state.go('updateCharity', {
                'id': obj.id
            });
        }
        $scope.showFilterBar = function() {
          //$rootScope.isshowtab = false;
            filterBarInstance = $ionicFilterBar.show({
                items: $scope.charity,
                update: function(filteredItems, filterText) {
                    $scope.charity = filteredItems;
                    if($scope.charity.length==0){
                    $rootScope.shownote = true;
                  }
                  else
                  {
                    $rootScope.shownote = false;
                    vm.lat = filteredItems[0].lat;
                    vm.lng = filteredItems[0].lng;
                  }
                    if (filterText) {
                        console.log(filterText);
                    }
                },
                done: function() {
                    var input = document.querySelector("ion-filter-bar input.filter-bar-search");
                    if (input) {
                        angular.element(input).attr("placeholder", "Search "+ $rootScope.currentTab);
                    }
                },
                cancel: function(){
                  //$rootScope.isshowtab = true;
                }
            });
        };

        $scope.refreshItems = function() {
            if (filterBarInstance) {
                filterBarInstance();
                filterBarInstance = null;
            }

            $timeout(function() {
                getItems();
                $scope.$broadcast('scroll.refreshComplete');
            }, 1000);
        };
        $scope.openReport = function(obj)
        {
          var lat = 0;
          var lng= 0;
          if (navigator.geolocation) navigator.geolocation.getCurrentPosition(onPositionUpdate);
            function onPositionUpdate(position) {
                console.log(position);
                lat = position.coords.latitude;
                lng = position.coords.longitude;
            }
          var mypopup = $ionicPopup.show({
            template: '<input type="text" ng-model="data.name" placeholder="Your Name"></input><input type="email" ng-model="data.email" placeholder="Email"></input><input type="tel" ng-model="data.phone" placeholder="Phone"></input><textarea ng-model="data.message" placeholder="Message"></textarea>'+($rootScope.allowlocation?'<ion-checkbox ng-model="data.location" style="border:0;margin-top:10px">Add your location </ion-checkbox>':'')+'<p class="error">{{data.error}}</p>',
            title: 'Contact '+obj.charityname+'?',
            subTitle: null,
            cssClass: 'openreport',
            scope: $scope,
            buttons: [
              { text: 'Cancel' },
              {
                text: '<b>Send</b>',
                type: 'button-positive',
                onTap: function(e) {
                  if (!$scope.data.name) {
                    e.preventDefault();
                    $scope.data.error="Please enter Your Name!";
                    return false;
                  }
                  if (!$scope.data.email) {
                    e.preventDefault();
                    $scope.data.error="Please enter Email!";
                    return false;
                  }
                  if (!$scope.data.message) {
                    e.preventDefault();
                    $scope.data.error="Please enter the message you want to communicate to this service";
                    return false;
                  }
                  if(!$scope.data.phone){
                    $scope.data.phone='';
                  }
                    var feedbackRef = new Firebase(refurl + "feedback");
                    var allfeedback = $firebaseArray(feedbackRef);

                    allfeedback.$add({
                        message: $scope.data.message,
                        name: $scope.data.name,
                        email: $scope.data.email,
                        phone: $scope.data.phone,
                        subject: obj.charityname,
                        userid: obj.userid,
                        lat:$scope.data.location?lat:0,
                        lng:$scope.data.location?lng:0,
                        createdate: new Date().getTime(),
                        type:3
                      }).then(function(res) {
                        console.log(res);
                        $rootScope.sendnotificationreport(obj.charityname,'Check Feedback from "'+$scope.data.name+'".',obj.userid);
                        $ionicPopup.alert({
                            template: "Message Sent Successfully",
                        });
                        $scope.data.message="";
                        $scope.data.name="";
                        $scope.data.email="";
                        $scope.data.phone="";
                        return $scope.data.message;
                        myPopup.close();
                      });


                }
              }
            ]
          });
        }
        $scope.kudos=function(obj)
        {
          var kudoslist = localStorageService.get('kudos');
          if(kudoslist!=null && kudoslist.indexOf(obj.id)!=-1)
          {
            return false;
          }
            var refcharity =new Firebase(refurl+"/charity/"+obj.id);
            var kudos = 0;
            refcharity.on('value', function(snapshot) {
              if(snapshot.val().kudos!=undefined)
              {
                kudos = snapshot.val().kudos;
              }
            });
            refcharity.update({ kudos: kudos+1 });
            var myEl = angular.element( document.getElementById('kudos'+obj.id) );

            if(kudoslist==null)
            {kudoslist="";}
            localStorageService.set('kudos', kudoslist+";"+ obj.id);
            myEl.html(kudos +" Kudos");
            myEl.removeClass("ng-hide");
        }
        $scope.doRefresh = function() {

          $scope.charity = [];
          $scope.charityall = [];

          var myDays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
          var ref = new Firebase(refurl);
          ref.child('charity')
              //.orderByChild('service')
              //.equalTo($scope.servicename)
              .once('value', function(charitySnap) {
                  charitySnap.forEach(function(childSnapshot) {
                      var key = childSnapshot.key();
                      var childData = childSnapshot.val();
                      var obj = {
                          id: key,
                          avaibed:childData.avaibed,
                          charityname: childData.charityname,
                          email:childData.email,
                          phone:childData.phone,
                          userid: childData.userid,
                          service: childData.service,
                          category: childData.category.replace(/,/g,', '),
                          fulladdress: childData.address1 + ", " + childData.city + ", " + childData.state,
                          lat: childData.lat,
                          lng: childData.lng,
                          city:childData.city,
                          zip:childData.zip,
                          distance: "",
                          distancenumber:0,
                          status: "",
                          open:false,
                          kudos: childData.kudos==undefined?0: parseInt(childData.kudos),
                          showflag:childData.showflag,
                          showdonate: childData.showdonate,
                          pos:[],
                          servicetype:childData.servicetype,
                          age:childData.Age,
                          closed:false,
                          contact:childData.contact,
                          updateshelter:childData.updateshelter,
                          search: childData.charityname+","+childData.servicetype+","+childData.city+","+childData.zip+""+childData.description+","+childData.Age+","+childData.email+","+childData.website+","+childData.phone+","+childData.address+","+childData.state
                      }
                      if (childData.approved == 1) {
                        var day = myDays[new Date().getDay()];
                        var open = false;
                        var show = true;
                        var till='';
                        var until='';
                        var timecur = new Date('01/01/2016 ' + $filter('date')(new Date(), 'h:mm a'));
                        var datecur = new Date($filter('date')(new Date(), 'MM/dd/yyyy'));
                        var nexttime = 999999;
                        var nexthour = 999999999;
                        var nexttimeobj;
                            childData.schedule.forEach(function(schedule) {

                                var timefrom = new Date('01/01/2016 '+ schedule.fromstring);
                                var timeto = new Date('01/01/2016 '+schedule.tostring);

                                var datefrom = new Date(schedule.date);
                                var dateto = new Date(schedule.todate);

                                if (schedule.type == 'Date Range') {
                                  obj.search = obj.search+","+schedule.date+" "+schedule.fromstring+" "+schedule.tostring;
                                  obj.search = obj.search+","+schedule.todate+" "+schedule.fromstring+" "+schedule.tostring;
                                    if (timecur.getTime() >=timefrom.getTime() && timecur.getTime() <= timeto.getTime() &&
                                      datefrom.getTime()<= datecur.getTime() && dateto.getTime()>=datecur.getTime()
                                    ) {
                                        open = true;
                                        till = 'till '+schedule.tostring;
                                        return;
                                    }
                                    else if(datefrom.getTime()>=datecur.getTime())
                                    {
                                      var timeDiff = Math.abs(datefrom.getTime() - datecur.getTime());
                                      var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
                                      if(diffDays<nexttime)
                                      {
                                        nexttime = diffDays;
                                        nexttimeobj = schedule;
                                      }
                                    }
                                } else if(schedule.type=='Weekly'){
                                    if (schedule.day == day) {
                                      obj.search = obj.search+","+schedule.day+" "+schedule.fromstring+" "+schedule.tostring;
                                        if (timecur.getTime() >= timefrom.getTime() && timecur.getTime() <= timeto.getTime()) {
                                            open = true;
                                            till = 'till '+schedule.tostring;
                                            return;
                                        }
                                        else if(timecur.getTime()<timefrom.getTime())
                                        {
                                          if(nexthour>timefrom.getTime() - timecur.getTime())
                                          {
                                            nexttime = 0;
                                            nexthour = timefrom.getTime() - timecur.getTime();
                                            nexttimeobj = schedule;
                                          }
                                        }
                                        else if(timecur.getTime()>timefrom.getTime())
                                        {
                                          if(nexttime>7)
                                          {
                                            nexttime=7;
                                            nexttimeobj = schedule;
                                          }
                                        }
                                    }
                                    else if(datecur.getDay()<getday(schedule.day))
                                    {
                                      if(nexttime> getday(schedule.day)-datecur.getDay())
                                      {
                                        nexttime = getday(schedule.day)-datecur.getDay();
                                        nexttimeobj = schedule;
                                      }
                                    }
                                    else if(datecur.getDay()>getday(schedule.day))
                                    {
                                      if(nexttime> getday(schedule.day)+7-datecur.getDay())
                                      {
                                        nexttime = getday(schedule.day)+7-datecur.getDay();
                                        nexttimeobj = schedule;
                                      }
                                    }
                                }
                                else if(schedule.type=='Open 24/7')
                                {
                                  open = true;
                                  till = '24/7';
                                  return;
                                }
                                else if(schedule.type=='Monthly')
                                {
                                  if(obj.id=="-KeoA0v_OEVbOr74MH46")
                                {
                                  console.log('test');
                                }
                                  var curdate=  new Date();
                                  var lstperiod=["First","Second","Third","Fourth","Fifth"];
                                  var periodnum = parseInt(curdate.getDate()/7) + (curdate.getDate()%7>0?1:0);
                                  var period = lstperiod[periodnum-1];
                                  if (schedule.day == day && period == schedule.period) {
                                    obj.search = obj.search+","+schedule.day+" "+schedule.fromstring+" "+schedule.tostring;
                                      if (timecur.getTime() >= timefrom.getTime() && timecur.getTime() <= timeto.getTime()) {
                                          open = true;
                                          till = 'till '+schedule.tostring;
                                          return;
                                      }
                                      else if(timecur.getTime()<timefrom.getTime()){
                                        nexttime=0;
                                        nexttimeobj = schedule;
                                      }
                                      else if(nexttime>35){
                                        nexttime=35;
                                        nexttimeobj = schedule;
                                      }
                                  }
                                  else if(schedule.period=='Last' && schedule.day == day && datecur.getDate() == GetDateofLastDay(schedule.day).getDate())
                                  {
                                    if (timecur.getTime() >= timefrom.getTime() && timecur.getTime() <= timeto.getTime()) {
                                        open = true;
                                        till = 'till '+schedule.tostring;
                                        return;
                                    }
                                    else if(timecur.getTime()<timefrom.getTime()){
                                      nexttime=0;
                                      nexttimeobj = schedule;
                                    }
                                    else if(nexttime>GetDateofLastDay(schedule.day).getDate()){
                                      nexttime=GetDateofLastDay(schedule.day).getDate();
                                      nexttimeobj = schedule;
                                    }
                                  }
                                  else if(schedule.period=='Last')
                                  {
                                    until= "until Last"+ " "+ getshortday(schedule.day)+" "  +schedule.fromstring +".";
                                  }
                                  else {
                                    if(periodnum<getperiod(schedule.period))
                                    {
                                      if(nexttime>(getperiod(schedule.period)-periodnum)*7)
                                      {
                                        nexttime = (getperiod(schedule.period)-periodnum)*7;
                                        nexttimeobj = schedule;
                                      }
                                    }
                                    else
                                    {
                                      if(nexttime>(getperiod(schedule.period)+5-periodnum)*7)
                                      {
                                        nexttime = (getperiod(schedule.period)+5-periodnum)*7;
                                        nexttimeobj = schedule;
                                      }
                                    }
                                  }
                                }
                            });
                            //close schedulechildData.schedule.forEach(function(schedule) {
                            if(childData.closeschedule!=undefined)
                            {
                            childData.closeschedule.forEach(function(schedule) {
                                var timefrom = new Date('01/01/2016 '+ schedule.fromstring);
                                var timeto = new Date('01/01/2016 '+schedule.tostring);

                                var datefrom = new Date(schedule.date);
                                var dateto = new Date(schedule.todate);
                                if(schedule.type=='Permanently Closed')
                                {
                                  obj.closed=true;
                                }
                                else if (schedule.type == 'Date Range') {
                                  obj.search = obj.search+","+schedule.date+" "+schedule.fromstring+" "+schedule.tostring;
                                  if(datefrom.getTime()<= datecur.getTime() && dateto.getTime()>datecur.getTime() && schedule.fromstring ==undefined && schedule.tostring==undefined)
                                  {
                                    open = false;
                                    until= "from " + $filter('date')(datefrom, 'MM/dd') +" - "+$filter('date')(dateto, 'MM/dd') +".";
                                    return;
                                  }
                                  else if(datefrom.getTime()== datecur.getTime() && dateto.getTime()==datecur.getTime() && schedule.fromstring ==undefined && schedule.tostring==undefined)
                                  {
                                    open = false;
                                    until= "until " + $filter('date')(datefrom, 'MM/dd') +".";
                                    return;
                                  }
                                  else  if (timecur.getTime() >=timefrom.getTime() && timecur.getTime() <= timeto.getTime() &&
                                      datefrom.getTime()<= datecur.getTime() && dateto.getTime()>=datecur.getTime()
                                    ) {
                                        open = false;
                                        until= "till " +schedule.tostring +".";
                                        return;
                                    }
                                }
                                else if(schedule.type=='Weekly'){
                                    if (schedule.day == day) {
                                          open = false;
                                          until = 'on '+schedule.day;
                                          return;
                                    }
                                }
                                else if(schedule.type=='Monthly')
                                {

                                  var curdate=  new Date();
                                  var lstperiod=["First","Second","Third","Fourth","Fifth"];
                                  var periodnum = parseInt(curdate.getDate()/7) + (curdate.getDate()%7>0?1:0);
                                  var period = lstperiod[periodnum-1];
                                  if (schedule.day == day && period == schedule.period) {
                                    obj.search = obj.search+","+schedule.day+" "+schedule.fromstring+" "+schedule.tostring;
                                      if (timecur.getTime() >= timefrom.getTime() && timecur.getTime() <= timeto.getTime()) {
                                          open = false;
                                          until= "until "+ getshortordinal(schedule.period) + " "+ getshortday(schedule.day)+" till "  +schedule.tostring +".";
                                          return;
                                      }
                                      else if(schedule.fromstring ==undefined && schedule.tostring==undefined)
                                      {
                                        open = false;
                                        until= "until "+ getshortordinal(schedule.period) + " "+ getshortday(schedule.day)+".";
                                        return;
                                      }
                                      else if(timecur.getTime()< timefrom.getTime() && till=='24/7')
                                      {
                                        till = "till "+schedule.tostring+".";
                                      }
                                  }
                                  else if(schedule.period=='Last' && schedule.day == day && datecur.getDate() == GetDateofLastDay(schedule.day).getDate())
                                  {
                                    if (timecur.getTime() >= timefrom.getTime() && timecur.getTime() <= timeto.getTime()) {
                                        open = false;
                                        until= "until "+ getshortordinal(schedule.period) + " "+ getshortday(schedule.day)+" till "  +schedule.tostring +".";
                                        return;
                                    }
                                    else if(schedule.fromstring ==undefined && schedule.tostring==undefined)
                                    {
                                      open = false;
                                      until= "until "+ getshortordinal(schedule.period) + " "+ getshortday(schedule.day)+".";
                                      return;
                                    }
                                    else if(timecur.getTime()< timefrom.getTime() && till=='24/7')
                                    {
                                      till = "till "+schedule.tostring+".";
                                    }
                                  }
                                }
                            });
                          }
                        if (show) {
                            obj.status = (open ? "Open "+till+"." : "Closed "+until);
                            obj.open = open;
                            if(obj.open==false && nexttimeobj!=undefined && until=='')
                            {
                              if(nexttimeobj.type=="Weekly")
                              {
                                var futureday = myDays[addDays(new Date(),1).getDay()];
                                if(day == nexttimeobj.day)
                                {
                                  obj.status = "Closed till " +nexttimeobj.fromstring +".";
                                }
                                else if(futureday == nexttimeobj.day)
                                {
                                  obj.status = "Closed until tomorrow " +nexttimeobj.fromstring+".";
                                }
                                else {
                                  obj.status = "Closed until "+nexttimeobj.day+" "  +nexttimeobj.fromstring+".";
                                }
                              }
                              else if(nexttimeobj.type=="Monthly")
                              {
                                obj.status= "Closed until "+ getshortordinal(nexttimeobj.period) + " "+ getshortday(nexttimeobj.day)+" "  +nexttimeobj.fromstring +".";
                              }
                              else if(nexttimeobj.type=="Date Range")
                              {
                                var futureday = addDays(new Date(),1);
                                var strfutureday = $filter('date')(futureday, 'MM/dd/yyyy');
                                if($filter('date')(new Date(), 'MM/dd/yyyy')==nexttimeobj.date)
                                {
                                  obj.status= "Closed till "+nexttimeobj.fromstring+".";
                                }
                                else if(strfutureday==nexttimeobj.date){
                                obj.status= "Closed until tomorrow "+nexttimeobj.fromstring+".";
                                }
                                else{
                                obj.status= "Closed until "+ nexttimeobj.date.substring(0,5) +" "+nexttimeobj.fromstring+".";
                              }
                              }
                            }
                            obj.pos = [obj.lat,obj.lng];
                            var distance;
                            if ($rootScope.lat && $rootScope.lng && obj.lat != undefined && obj.lng != undefined) {
                              distance = (getDistanceFromLatLonInKm($rootScope.lat,$rootScope.lng,obj.lat,obj.lng)*0.621371192).toFixed(1);
                              obj.distance = distance +" Miles";
                              obj.distancenumber = parseFloat(distance);
                            }
                            if (($rootScope.currentlocation==obj.city || $rootScope.currentlocation==obj.zip || $rootScope.currentlocation=="Current Location" || $rootScope.currentlocation=="") && childData.service.indexOf($scope.servicename)!=-1 && ($rootScope.open == open || $rootScope.open==false) && ((childData.category.indexOf($rootScope.Gender) != -1 && childData.category.indexOf('All') == -1) || $rootScope.Gender == 'All')) {
                              if($rootScope.topkudos==true && obj.distancenumber<50)
                              {
                                $scope.charity.push(obj);
                              }
                              else if($rootScope.topkudos==false){
                                $scope.charity.push(obj);
                              }
                                if(vm.distancemin == 0 || vm.distancemin>distance)
                                {
                                  vm.distancemin = distance;
                                  vm.lat = obj.lat;
                                  vm.lng = obj.lng;
                                }
                            }
                            $scope.charityall.push(obj);

                        }
                      }

                  })
              });
          $scope.$broadcast('scroll.refreshComplete');

        };

    });
