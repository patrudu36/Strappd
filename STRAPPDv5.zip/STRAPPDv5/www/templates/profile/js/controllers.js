appControllers.controller('loginCtrl',
    function($scope, $rootScope, $location, $state, $http, $ionicPopup, $ionicHistory,$firebaseObject,$firebaseArray,localStorageService) {
        var ref = new Firebase(refurl);
        $scope.loginData = {
            email: '',
            password: ''
        };
        $scope.goback = function() {
            window.history.back();
        }

        $scope.signIn = function() {
            if ($scope.loginData.email == '' || $scope.loginData.password == '') {
                $ionicPopup.alert({
                    title: "Alert",
                    template: "Enter login details",
                });
                return;
            }
            showloading();
            firebase.auth().signInWithEmailAndPassword($scope.loginData.email,$scope.loginData.password).then(function(authData) {
                hideloading();

                    localStorageService.set('email', $scope.loginData.email);
                    localStorageService.set('pass', $scope.loginData.password);

                    $rootScope.currentEmail = $scope.loginData.email;
                    $rootScope.currentUser=authData.user;
                    $rootScope.IsLogin = true;

                    debugger;
                    //var refuserfeedback = new Firebase(refurl + "/feedback");
                    //query = refuserfeedback.orderByChild("userid").equalTo( authData.uid);
                    //$rootScope.userFeedback = $firebaseArray(query);
                    $rootScope.userFeedback = 0;
                    var refuserfeedback = new Firebase(refurl + "/feedback");
                    refuserfeedback.orderByChild("userid")
                        .equalTo(authData.user.uid)
                        .once('value', function(shelterSnap) {
                            shelterSnap.forEach(function(childSnapshot) {
                                if (childSnapshot.val().type == 3) {
                                    $rootScope.userFeedback = $rootScope.userFeedback + 1;
                                }
                            });
                        });

                    var refuser = new Firebase(refurl+"/users/"+authData.user.uid);



                    refuser.once('value',function(userSnap)
                    {
                      if(userSnap.val().isadmin==1)
                      {
                        $rootScope.IsAdmin = true;
                      }
                    });
                    $state.go('charity', {
                        'service': 'Food'
                    },{cache: false});
            }).catch(function(error) {
              // Handle Errors here.
              if (error.code!=undefined) {
                hideloading();
                $ionicPopup.alert({
                    title: "Alert",
                    template: error.message,
                });
              }
            });
        }

    });
appControllers.controller('changePassCtrl',
    function($scope, $rootScope, $location, $state, $http, $ionicPopup, $ionicHistory) {
        var ref = new Firebase(refurl);
        $scope.changePassData = {
            oldPass: '',
            newPass: '',
            newsPassConfirm:''
        };
        $scope.changePass = function() {
            if ($scope.changePassData.oldPass == '' || $scope.changePassData.newPass == ''|| $scope.changePassData.newsPassConfirm == '') {
                $ionicPopup.alert({
                    title: "Alert",
                    template: "Enter password details",
                });
                return;
            }
            if($scope.changePassData.newPass!=$scope.changePassData.newsPassConfirm)
            {
                $ionicPopup.alert({
                    title: "Alert",
                    template: "New password and confirm new password is not match !",
                });
                return;
            }
            showloading();
            var user = firebase.auth().currentUser;
            user.updatePassword($scope.changePassData.newPass).then(function() {
              // Update successful.
                hideloading();

                      $scope.changePassData = {
                          oldPass: '',
                          newPass: '',
                          newsPassConfirm:''
                      };
                        if (error) {
                            $ionicPopup.alert({
                                title: "Alert",
                                template: "Enter login details",
                            });
                            return;
                        } else {
                            $ionicPopup.alert({
                                title: 'Change password success',
                                template: 'Please login with New Password'
                            }).then(function(){
                                logout();
                                $state.go('login')
                            });
                        }
            }).catch(function(error) {
              // An error happened.
              $ionicPopup.alert({
                  title: "Alert",
                  template: error.message,
              });
            });;
        }

    });
appControllers.controller('forgotCtrl', function($scope, $state, $http, $ionicPopup, $rootScope) {
    $scope.goback = function() {
        window.history.back();
    }
    var ref = new Firebase(refurl);
    $scope.forgotData = {
        email: ''
    };

    $scope.forgot = function() {

        if ($scope.forgotData.email == '') {
            $ionicPopup.alert({
                title: "Alert",
                template: "Please enter email",
            });
            return;
        }
        $rootScope.ForgotEmail=$scope.forgotData.email;
        showloading();
        auth.sendPasswordResetEmail($scope.forgotData.email).then(function() {
            hideloading();

                console.log("Password reset email sent successfully!");
                $ionicPopup.alert({
                    title: "Alert",
                    template: "Password reset email sent successfully!",
                }).then(function(){
                    $state.go("login");
                });
        }).catch(function(error) {
          // An error happened.
          $ionicPopup.alert({
              title: "Alert",
              template: error.message,
          });
        });
    }

});
appControllers.controller('signupCtrl',
    function($scope, $rootScope, $state, $http, $ionicPopup,$location) {
        $scope.goback = function() {
            window.history.back();
        }
        var ref = new Firebase(refurl);
        $scope.user = {
            name: '',
            username: '',
            phone: '',
            password: '',
            email: '',
            isadmin:0
        };
        var showAlert = function(title, template) {
            $ionicPopup.alert({
                title: title,
                template: template,
            });
        }
        var validateuser = function() {
            if (!$scope.user.name) {
                showAlert("Warning", "Please enter Charity or Non-Profit Name");
                return false;
            }
            if (!$scope.user.email) {
                showAlert("Warning", "Please enter email");
                return false;
            }
            if (!$scope.user.phone) {
                showAlert("Warning", "Please enter Phone Number");
                return false;
            }
            if (!$scope.user.password) {
                showAlert("Warning", "Please enter password");
                return false;
            }

            return true;
        }
        $scope.signUp = function() {
            var isvalid = validateuser();
            if (isvalid == false)
                return;
            showloading();
            debugger;
            firebase.auth().createUserWithEmailAndPassword($scope.user.email,$scope.user.password).then(function(authData){
                hideloading();
debugger;
                      var uidRef = new Firebase(refurl + "users/" + authData.user.uid + "/");
                      uidRef.set({
                          userid: authData.user.uid,
                          email: $scope.user.email,
                          name: $scope.user.name,
                          phone: $scope.user.phone,
                          isadmin: 0,
                          //devicetoken: $rootScope.devicetoken
                      });
                        $rootScope.currentEmail = $scope.user.email;
                        $rootScope.currentUser=authData.user;
                        $rootScope.IsLogin = true;
                        $state.go("charity", {
                          'service': 'Food'
                        });
            }).catch(function(error) {
              // Handle Errors here.
              debugger;
              var errorCode = error.code;
              $ionicPopup.alert({
                  title: "Alert",
                  template: "["+error.code+"] " + error.message,
              });
            });
            };
    })
