
appControllers.controller('approvalsCtrl', function($scope,$rootScope, $state, $http, $ionicPopup,$firebaseArray, $firebaseObject, $stateParams,$ionicFilterBar) {
  var ref = new Firebase(refurl+"/charity");
  /*$scope.charity =[];*/
  $scope.filter = {};
  $scope.filter.charityname = "";
  $scope.services = ["Food","Shelter","Health","Resources","Work"];
 var query = ref.orderByChild("approved").equalTo(0);
 $scope.charity = $firebaseArray(query);


   $scope.showFilterBar = function() {
     //$rootScope.isshowtab = false;
       filterBarInstance = $ionicFilterBar.show({
           items: $scope.charity,
           update: function(filteredItems, filterText) {
               $scope.charity = filteredItems;
               if (filterText) {
                   console.log(filterText);
               }
           },
           done: function() {
               var input = document.querySelector("ion-filter-bar input.filter-bar-search");
               if (input) {
                   angular.element(input).attr("placeholder", "Search services");
               }
           },
           cancel: function(){
             //$rootScope.isshowtab = true;
           }
       });
   };

  $scope.removeCharity=function(id,index)
  {
    var fredRef = new Firebase(refurl+"/charity/"+id);
    var confirmPopup = $ionicPopup.confirm({
        title: "",
        template: 'Do you want to Delete this Service?',
        cancelText: 'No',
        okText: 'Yes'
    }).then(function(res) {
      if (res) {
        var onComplete = function(error) {
          if (error) {
            alert(error);
          } else {
            var myEl = angular.element( document.querySelector( '#charity'+idx ) );
            myEl.remove();
            $ionicPopup.alert({
                title: "",
                template: "Remove charity successfully",
            });
          }
        };
        fredRef.remove(onComplete);

    }
    })

  }
  $scope.getshortday = function(day)
{
  if(day=='Monday'){
    return 'Mon';
  }else if(day=='Tuesday')
  {
    return 'Tue';
  }
  else if(day=='Wednesday')
  {
    return 'Wed';
  }
  else if(day=='Thursday')
  {
    return 'Thu';
  }
  else if(day=='Friday')
  {
    return 'Fri';
  }
  else if(day=='Saturday')
  {
    return 'Sat';
  }
  else if(day=='Sunday')
  {
    return 'Sun';
  }
}
$scope.getshortordinal = function(ordinal)
{
if(ordinal=='First'){
  return '1st';
}else if(ordinal=='Second')
{
  return '2nd';
}
else if(ordinal=='Third')
{
  return '3rd';
}
else if(ordinal=='Fourth')
{
  return '4th';
}
else if(ordinal=='Fifth')
{
  return '5th';
}
}
  $scope.editCharity= function(id)
  {
    debugger;
    $state.go('updateCharity', {
      'id': id
    });
  }
  $scope.ApproveSelect = function(service)
  {
    function filterSelect(obj) {
      if( obj.service.indexOf(service)!=-1)
      {
        return obj.checked;
      }
    }
    var charityItemSelect = $scope.charity.filter(filterSelect).map(function(obj) {
        return obj.$id
    });
    if(charityItemSelect.length==0)
    {
      $ionicPopup.alert({
          title: "",
          template: "Please select a Charity to approve",
      });
      return;
    }
    debugger;
    charityItemSelect.forEach(function(id)  {
      var refcharity = new Firebase(refurl+"/charity/"+id);
      refcharity.update({ approved: 1 });
    });
    $ionicPopup.alert({
        title: "",
        template: "Approved successfully",
    });
    initcharity();
  }
  $scope.DeleteSelect = function(service)
  {
    function filterSelect(obj) {
      if( obj.service.indexOf(service)!=-1)
      {
        return obj.checked;
      }
    }
    var charityItemSelect = $scope.charity.filter(filterSelect).map(function(obj) {
        return obj.$id
    });
    if(charityItemSelect.length==0)
    {
      $ionicPopup.alert({
          title: "",
          template: "Please select a Charity to delete",
      });
      return;
    }
    charityItemSelect.forEach(function(id)  {
      var refcharity = new Firebase(refurl+"/charity/"+id);
      refcharity.remove();
    });
    $ionicPopup.alert({
        title: "",
        template: "Deleted successfully",
    });
    initcharity();
  }
  $scope.ApproveAll = function(service)
  {
    function filterSelect(obj) {
      if( obj.service.indexOf(service)!=-1)
      {
        return true;
      }
    }
    var charityItemSelect = $scope.charity.filter(filterSelect).map(function(obj) {
        return obj.$id
    });
    if(charityItemSelect.length==0)
    {
      return;
    }
    charityItemSelect.forEach(function(id)  {
      var refcharity = new Firebase(refurl+"/charity/"+id);
      refcharity.update({ approved: 1 });
    });
      $ionicPopup.alert({
          title: "",
          template: "Approved successfully",
      });
      initcharity();
  }
  var initcharity=function()
  {
    var ref = new Firebase(refurl+"/charity");
    var query = ref.orderByChild("approved").equalTo(0);
    $scope.charity = $firebaseArray(query);

  }
});
appControllers.controller('managecharityCtrl', function($scope,$rootScope, $state, $http, $ionicPopup,$firebaseArray, $firebaseObject, $stateParams,$ionicFilterBar) {
  var ref = new Firebase(refurl);
  var refcharity = new Firebase(refurl+"/charity");
  $scope.filter = {};
  $scope.filter.charityname = "";
  var authData = firebase.auth().currentUser;
  if (authData) {
      console.log("Authenticated user with uid:", authData.uid);
  } else {
      $state.go("login");
  }
  $scope.services = ["Food","Shelter","Health","Resources","Work"];
  if(!$rootScope.IsAdmin)
  {
    debugger;
    var query = refcharity.orderByChild("userid").equalTo(authData.uid);
    $scope.charity = $firebaseArray(query);
  }
  else {
    $scope.charity = $firebaseArray(refcharity);
  }
  $scope.getshortday = function(day)
{
  if(day=='Monday'){
    return 'Mon';
  }else if(day=='Tuesday')
  {
    return 'Tue';
  }
  else if(day=='Wednesday')
  {
    return 'Wed';
  }
  else if(day=='Thursday')
  {
    return 'Thu';
  }
  else if(day=='Friday')
  {
    return 'Fri';
  }
  else if(day=='Saturday')
  {
    return 'Sat';
  }
  else if(day=='Sunday')
  {
    return 'Sun';
  }
}
$scope.getshortordinal = function(ordinal)
{
if(ordinal=='First'){
  return '1st';
}else if(ordinal=='Second')
{
  return '2nd';
}
else if(ordinal=='Third')
{
  return '3rd';
}
else if(ordinal=='Fourth')
{
  return '4th';
}
else if(ordinal=='Fifth')
{
  return '5th';
}
}

  $scope.showFilterBar = function() {
    //$rootScope.isshowtab = false;
      filterBarInstance = $ionicFilterBar.show({
          items: $scope.charity,
          update: function(filteredItems, filterText) {
              $scope.charity = filteredItems;
              if (filterText) {
                  console.log(filterText);
              }
          },
          done: function() {
              var input = document.querySelector("ion-filter-bar input.filter-bar-search");
              if (input) {
                  angular.element(input).attr("placeholder", "Search services");
              }
          },
          cancel: function(){
            //$rootScope.isshowtab = true;
          }
      });
  };
  $scope.removeCharity=function(id,index)
  {
    var fredRef = new Firebase(refurl+"/charity/"+id);
    var confirmPopup = $ionicPopup.confirm({
        title: "",
        template: 'Do you want to Delete this Service?',
        cancelText: 'No',
        okText: 'Yes'
    }).then(function(res) {
      if (res) {
        var onComplete = function(error) {
          if (error) {
            alert(error);
          } else {
            var myEl = angular.element( document.querySelector( '#charity'+idx ) );
            myEl.remove();
            $ionicPopup.alert({
                title: "",
                template: "Remove charity successfully",
            });
          }
        };
        fredRef.remove(onComplete);

    }
    })
  }

  $scope.editCharity= function(id)
  {
    debugger;
    $state.go('updateCharity', {
      'id': id
    });
  }
  var initcharity=function()
  {
    var ref = new Firebase(refurl+"/charity");
    var query = ref.orderByChild("userid").equalTo($rootScope.currentUser.uid);
    $scope.charity = $firebaseArray(query);

  }
});
appControllers.controller('manageuserCtrl', function($scope, $state, $http, $ionicPopup, $firebaseObject, $stateParams,$ionicFilterBar) {
  var ref = new Firebase(refurl+"/users");
  $scope.users =[];
  $scope.filter = {};
  $scope.filter.email = "";
  ref.once("value", function(snapshot) {
    snapshot.forEach(function(childSnapshot) {
      var key = childSnapshot.key();
      var childData = childSnapshot.val();
      var obj = {
        email: childData.email,
        id:key,
        checked:childData.isadmin==1
      }
      $scope.users.push(obj);
    });
  });
  $scope.showFilterBar = function() {
    //$rootScope.isshowtab = false;
      filterBarInstance = $ionicFilterBar.show({
          items: $scope.users,
          update: function(filteredItems, filterText) {
              $scope.users = filteredItems;
              if (filterText) {
                  console.log(filterText);
              }
          },
          done: function() {
              var input = document.querySelector("ion-filter-bar input.filter-bar-search");
              if (input) {
                  angular.element(input).attr("placeholder", "Search CharityUser Email");
              }
          },
          cancel: function(){
            //$rootScope.isshowtab = true;
          }
      });
  };
  $scope.SetApprove = function(id,check)
  {
    var refuser = new Firebase(refurl+"/users/"+id);
    refuser.update({ isadmin: check?1:0 });
  }
  $scope.ApproveSelect = function()
  {
    function filterSelect(obj) {
        return obj.checked;
    }
    var userItemSelect = $scope.users.filter(filterSelect).map(function(obj) {
        return obj.id
    });
    if(userItemSelect.length==0)
    {
      $ionicPopup.alert({
          title: "",
          template: "Please select a User to approve",
      });
      return;
    }
    userItemSelect.forEach(function(id)  {
      var refuser = new Firebase(refurl+"/users/"+id);
      refuser.update({ isadmin: 1 });
    });

      $ionicPopup.alert({
          title: "",
          template: "Approved successfully",
      });
      inituser();
  }
  var inituser=function()
  {
    var ref = new Firebase(refurl+"/users");
    $scope.users =[];
    $scope.filter = {};
    $scope.filter.email = "";
    ref.orderByChild("isadmin").equalTo(0).once("value", function(snapshot) {
      snapshot.forEach(function(childSnapshot) {
        var key = childSnapshot.key();
        var childData = childSnapshot.val();
        var obj = {
          email: childData.email,
          id:key,
          checked:childData.isadmin==1
        }
        $scope.users.push(obj);
      });
    });
  }
});


appControllers.controller('manageshelterCtrl', function($scope,$rootScope, $state, $http, $ionicPopup,$firebaseArray, $firebaseObject, $stateParams,$filter,$ionicFilterBar) {
  var ref = new Firebase(refurl);
  var refcharity = new Firebase(refurl+"/charity");
  /*$scope.charity =[];*/
  $scope.filter = {};
  $scope.filter.charityname = "";
  var authData = firebase.auth().currentUser;
  if (authData) {
      console.log("Authenticated user with uid:", authData.uid);
  } else {
      $state.go("login");
  }
  $scope.noshelter = true;
  $scope.nobed=true;
  var query = refcharity.orderByChild("userid").equalTo(authData.uid);
  $scope.charity = $firebaseArray(query);

  refcharity.orderByChild("userid").equalTo(authData.uid).once('value', function(charitySnap) {
        charitySnap.forEach(function(childSnapshot) {
            var item = childSnapshot.val();
            if(item.service.indexOf('Shelter')!=-1)
            {
              $scope.noshelter=false;
            }
            if(item.avaibed && item.avaibed>0){
              if($scope.nobed==true){
                debugger;
                $scope.nobed=false;
              }
            }
        });

      });
      $scope.showFilterBar = function() {
        //$rootScope.isshowtab = false;
          filterBarInstance = $ionicFilterBar.show({
              items: $scope.charity,
              update: function(filteredItems, filterText) {
                  $scope.charity = filteredItems;
                  if (filterText) {
                      console.log(filterText);
                  }
              },
              done: function() {
                  var input = document.querySelector("ion-filter-bar input.filter-bar-search");
                  if (input) {
                      angular.element(input).attr("placeholder", "Search services");
                  }
              },
              cancel: function(){
                //$rootScope.isshowtab = true;
              }
          });
      };
  $scope.AddBeds = function(id)
  {
    var refcharity = new Firebase(refurl+"/charity/"+id);
    refcharity.once('value', function(charitySnap) {
        refcharity.update({ avaibed: charitySnap.val().avaibed+1 ,updateshelter: $filter('date')(new Date(), 'MM/dd/yyyy h:mm a') });
    });
  }
  $scope.UpdateAvaiBed = function(item)
  {
    if(item.avaibed==undefined)
    {
      item.avaibed = "";
    }
    if(item.totalbed<item.avaibed)
    {
      $ionicPopup.alert({
          template: "‘Available Beds’ should be less than or equal ‘Total Beds’!",
      });
      return false;
    }
    var avaibed = item.avaibed;
    if(item.avaibed=="")
    {avaibed = 0}
    var refcharity = new Firebase(refurl+"/charity/"+item.$id);
    refcharity.update({ avaibed: avaibed,updateshelter: $filter('date')(new Date(), 'MM/dd/yyyy h:mm a') });

  }
  $scope.SubtractBeds = function(id)
  {
    debugger;
    var refcharity = new Firebase(refurl+"/charity/"+id);
    refcharity.once('value', function(charitySnap) {
      if(charitySnap.val().avaibed>0)
      {
        refcharity.update({ avaibed: charitySnap.val().avaibed-1,updateshelter: $filter('date')(new Date(), 'MM/dd/yyyy h:mm a')  });

      }
    });
  }
});
appControllers.controller('adminshelterCtrl', function($scope,$rootScope, $state, $http, $ionicPopup,$firebaseArray, $firebaseObject, $stateParams,$filter,$ionicFilterBar) {
  $scope.filter = {};
  $scope.filter.charityname = "";
  var ref = new Firebase(refurl);
  var authData = firebase.auth().currentUser;
  if (authData) {
      console.log("Authenticated user with uid:", authData.uid);
  } else {
      $state.go("login");
  }
  $scope.charity =[];
  //var query = refcharity.orderByChild("service").equalTo('Shelter');
  ref.child('charity')
  .once('value', function(charitySnap) {
      charitySnap.forEach(function(childSnapshot) {
        var key = childSnapshot.key();
        var childData = childSnapshot.val();
        if(childData.service.indexOf('Shelter')!=-1)
        {
          childData.zip = key;
          $scope.charity.push(childData);
        }
      })
    });
    refresh= function(){
      $scope.charity=[];
      var ref = new Firebase(refurl);
      ref.child('charity')
      .once('value', function(charitySnap) {
          charitySnap.forEach(function(childSnapshot) {
            var key = childSnapshot.key();
            var childData = childSnapshot.val();
            if(childData.service.indexOf('Shelter')!=-1)
            {
              childData.zip = key;
              $scope.charity.push(childData);
            }
          })
        });
    }
  //$scope.charity = $firebaseArray(query);
  $scope.AddBeds = function(id)
  {
    var refcharity = new Firebase(refurl+"/charity/"+id);
    refcharity.once('value', function(charitySnap) {
      if(charitySnap.val().totalbed==charitySnap.val().avaibed)
      {
        $ionicPopup.alert({
            template: "‘Available Beds’ should be less than or equal ‘Total Beds’!",
        });
        return false;
      }
      refcharity.update({ avaibed: charitySnap.val().avaibed+1,updateshelter: $filter('date')(new Date(), 'MM/dd/yyyy h:mm a')  });
      refresh();
    });
  }
  $scope.showFilterBar = function() {
    //$rootScope.isshowtab = false;
      filterBarInstance = $ionicFilterBar.show({
          items: $scope.charity,
          update: function(filteredItems, filterText) {
              $scope.charity = filteredItems;
              if (filterText) {
                  console.log(filterText);
              }
          },
          done: function() {
              var input = document.querySelector("ion-filter-bar input.filter-bar-search");
              if (input) {
                  angular.element(input).attr("placeholder", "Search services");
              }
          },
          cancel: function(){
            //$rootScope.isshowtab = true;
          }
      });
  };
  $scope.SubtractBeds = function(id)
  {
    debugger;
    var refcharity = new Firebase(refurl+"/charity/"+id);
    refcharity.once('value', function(charitySnap) {

      if(charitySnap.val().avaibed>0)
      {
        refcharity.update({ avaibed: charitySnap.val().avaibed-1,updateshelter: $filter('date')(new Date(), 'MM/dd/yyyy h:mm a')  });
      }
    });
    refresh();
  }
  $scope.UpdateAvaiBed = function(item)
  {
    if(item.avaibed==undefined)
    {
      item.avaibed = "";
    }
    if(item.totalbed<item.avaibed)
    {
      $ionicPopup.alert({
          template: "‘Available Beds’ should be less than or equal ‘Total Beds’!",
      });
      return false;
    }
    var avaibed = item.avaibed;
    if(item.avaibed=="")
    {avaibed = 0}
    var refcharity = new Firebase(refurl+"/charity/"+item.$id);
    refcharity.update({ avaibed: avaibed,updateshelter: $filter('date')(new Date(), 'MM/dd/yyyy h:mm a')  });

  }
});
