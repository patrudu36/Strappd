appControllers.controller('introCtrl', function($rootScope,$state, $scope, $ionicPopup, $filter,$firebaseArray,$ionicFilterBar,localStorageService, $ionicSlideBoxDelegate ) {

  $scope.skipintro = function()
  {
    $rootScope.isshowtab =true;
    localStorageService.set('skipintro', '1');
    $state.go('charity', {
        'service': 'Food'
    },{cache: false});
  }
  $scope.next = function() {
   $ionicSlideBoxDelegate.next();
 };
 $scope.previous = function() {
   $ionicSlideBoxDelegate.previous();
 };
});
